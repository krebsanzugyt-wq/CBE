import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  Pressable,
  ScrollView,
  TextInput,
  Modal,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  ActivityIndicator,
  Animated,
  Easing,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { createClient } from "@supabase/supabase-js";

const STR = {
  de: {
    tabs: { today: "Heute", plans: "Training", library: "Übungen", progress: "Progress", planner: "Planer" },
    today: {
      title: "Heute",
      quickLog: "Schnell-Log",
      note: "Notiz (optional)",
      add: "Hinzufügen",
      recent: "Letzte Einträge",
      workouts: "Letzte Workouts",
      empty: "Noch keine Einträge.",
      workoutsEmpty: "Noch keine Workouts gespeichert.",
      open: "Öffnen",
      close: "Schließen",
    },
    plans: {
      title: "Training",
      create: "Plan erstellen",
      namePlaceholder: "z.B. Full Body A",
      open: "Öffnen",
      back: "Zurück",
      editorTitle: "Plan bearbeiten",
      addExercise: "Übung hinzufügen",
      restDefault: "Standard-Pause (Sek.)",
      exerciseEmpty: "Noch keine Übungen im Plan.",
      sets: "Sätze",
      addSet: "+ Satz",
      remove: "Entfernen",
      startWorkout: "Workout starten",
      hint: "Plan = Vorlage. Werte trägst du im Workout ein.",
    },
    workout: {
      title: "Workout",
      back: "Zurück",
      finish: "Workout beenden",
      progress: "Fortschritt",
      rest: "Pause",
      skip: "Skip",
      resume: "Weiter",
      pause: "Pause",
      doneHint: "Trage kg/reps ein. Tippe auf Done > Pause startet automatisch.",
      kg: "kg",
      reps: "reps",
      done: "Done",
      undo: "Undo",
    },
    history: {
      title: "Workout Details",
      summary: "Zusammenfassung",
      duration: "Dauer",
      done: "Done",
    },
    library: {
      title: "Übungsbibliothek",
      search: "Suchen (englischer Name)...",
      filters: { category: "Kategorie", muscle: "Muskel" },
      addToPlan: "Zum Plan",
      close: "Schließen",
      noResults: "Keine Treffer.",
      customTitle: "Eigene Übungen",
      addCustom: "Eigene Übung anlegen",
      name: "Name (Englisch)",
      category: "Kategorie",
      muscle: "Muskelgruppe",
      save: "Speichern",
      delete: "Löschen",
      emptyCustom: "Noch keine eigenen Übungen.",
      dataTitle: "Daten / Import / Export",
      importExercises: "Übungen importieren (JSON)",
      exportData: "Export (App-Daten)",
      importData: "Import (App-Daten)",
      tip: "Tipp: Mit Export/Import kannst du deinen Stand 1:1 an Freunde schicken.",
    },
    calendar: {
      title: "Planer",
      add: "Eintrag hinzufügen",
      date: "Datum (YYYY-MM-DD)",
      label: "Titel (z.B. Run Zone 2)",
      empty: "Noch keine geplanten Einträge.",
    },
    common: {
      pasteHere: "Hier JSON einfügen...",
      error: "Fehler",
      success: "Erfolg",
    },
  },
};
const LANG = "de";

const DS = {
  spacing: { xs: 8, s: 12, m: 16, l: 20, xl: 26 },
  radius: { card: 20, button: 999, input: 16 },
  colors: {
    bg: "#F2F4F8",
    text: "#0B0B0F",
    muted: "#5C5C66",
    border: "rgba(12,20,38,0.08)",
    surface: "rgba(255,255,255,0.92)",
    surfaceSoft: "rgba(0,0,0,0.03)",
    accent: "#448EFF",
  },
  typography: {
    h1: { fontSize: 27, fontWeight: "700" },
    h2: { fontSize: 18, fontWeight: "800" },
    body: { fontSize: 14, fontWeight: "500" },
    small: { fontSize: 12, fontWeight: "600" },
  },
};

function useDebouncedValue(value, delay = 250) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}


/** =========================
 * FULL Exercise Database - Trainingsplan integriert
 * ========================= */
const BASE_EXERCISES = [
  // === BARBELL === inputType: "kg_reps" (default)
  { id: "ex_bench_press", name: "Bench Press", category: "Barbell", muscle: "Chest", source: "base", inputType: "kg_reps", howto: ["Schultern zurueck, Brust raus", "Fuesse fest am Boden", "Stange zur Brustwarze senken", "Ellbogen ~45 Grad"] },
  { id: "ex_back_squat", name: "Back Squat", category: "Barbell", muscle: "Legs", source: "base", inputType: "kg_reps", howto: ["Stange auf oberen Trapez", "Fuesse schulterbreit, Zehen leicht aussen", "Knie ueber Zehen, Huefte unter parallel", "Brust hoch, Ruecken gerade halten"] },
  { id: "ex_overhead_press", name: "Overhead Press", category: "Barbell", muscle: "Shoulders", source: "base", inputType: "kg_reps", howto: ["Enger Griff, Ellbogen vor der Stange", "Kopf zurueck, Stange gerade hoch druecken", "Lockout oben, Kopf durch", "Core anspannen, kein Hohlkreuz"] },
  { id: "ex_trap_bar_deadlift", name: "Trap Bar Deadlift", category: "Barbell", muscle: "Legs", source: "base", inputType: "kg_reps", howto: ["In die Mitte stellen, Griffe greifen", "Huefte zurueck, Brust raus", "Druck ueber die Fersen", "Hueftstreckung oben, Schultern zurueck"] },
  { id: "ex_rdl", name: "Romanian Deadlift (RDL)", category: "Barbell", muscle: "Legs", source: "base", inputType: "kg_reps", howto: ["Leicht gebeugte Knie, fixiert halten", "Huefte zurueck schieben, nicht runter", "Stange nah am Koerper fuehren", "Dehnung in Hamstrings spueren, dann Huefte strecken"] },
  { id: "ex_barbell_rows", name: "Barbell Rows", category: "Barbell", muscle: "Back", source: "base", inputType: "kg_reps", howto: ["45 Grad Oberkoerperneigung", "Stange zum Bauchnabel ziehen", "Schulterblatter zusammen", "Kontrolliert ablassen"] },
  { id: "ex_power_cleans", name: "Power Cleans", category: "Barbell", muscle: "Full Body", source: "base", inputType: "kg_reps", howto: ["Startposition wie Deadlift", "Explosiv Hueftstreckung", "Stange nah am Koerper", "Ellbogen schnell nach vorne, Frontrack fangen"] },
  { id: "ex_push_press", name: "Push Press", category: "Barbell", muscle: "Shoulders", source: "base", inputType: "kg_reps", howto: ["Kurzer Dip in den Knien", "Explosiv nach oben druecken", "Beine + Schultern zusammen", "Lockout oben"] },
  // === DUMBBELL ===
  { id: "ex_incline_db_press", name: "Incline DB Press (45deg)", category: "Dumbbell", muscle: "Chest", source: "base", inputType: "kg_reps", howto: ["Bank auf 45 Grad", "DBs neben Schultern, Ellbogen 45 Grad", "Hoch druecken, oben kurz halten", "Langsam ablassen, Dehnung unten"] },
  { id: "ex_incline_db_curl", name: "Incline DB Curl", category: "Dumbbell", muscle: "Arms", source: "base", inputType: "kg_reps", howto: ["Bank auf 30-45 Grad", "Arme haengen lassen, volle Dehnung", "Nur Unterarme bewegen", "Langsames Ablassen, kein Schwung"] },
  { id: "ex_bulgarian_split_squat", name: "Bulgarian Split Squat", category: "Dumbbell", muscle: "Legs", source: "base", inputType: "kg_reps", howto: ["Hinterer Fuss auf Bank", "Vorderes Knie ueber Zehen", "Aufrecht bleiben", "Reps pro Seite zaehlen"] },
  { id: "ex_single_leg_rdl", name: "Single-Leg RDL", category: "Dumbbell", muscle: "Legs", source: "base", inputType: "kg_reps", howto: ["Standbein leicht gebeugt", "Hinteres Bein + Oberkoerper = eine Linie", "DB gegenueber dem Standbein", "Reps pro Seite"] },
  { id: "ex_farmer_walks", name: "Farmer Walks", category: "Dumbbell", muscle: "Full Body", source: "base", inputType: "kg_dist", howto: ["Schwere DBs/KBs greifen", "Schultern zurueck und runter", "Aufrecht gehen, kurze Schritte", "40m pro Set, Griffkraft trainieren"] },
  // === MACHINE ===
  { id: "ex_lat_pulldown", name: "Lat Pulldown", category: "Machine", muscle: "Back", source: "base", inputType: "kg_reps", howto: ["Breiter Griff, leichte Ruecklage", "Stange zur oberen Brust ziehen", "Schulterblatter zusammen unten", "Kontrolliert zurueck"] },
  { id: "ex_leg_press", name: "Leg Press", category: "Machine", muscle: "Legs", source: "base", inputType: "kg_reps", howto: ["Fuesse schulterbreit, hoch auf Platte", "90 Grad in den Knien", "Nicht komplett durchstrecken", "Po bleibt auf dem Sitz"] },
  { id: "ex_chest_fly_machine", name: "Chest Fly (Machine)", category: "Machine", muscle: "Chest", source: "base", inputType: "kg_reps", howto: ["Ellbogen leicht gebeugt", "Zusammenfuehren vor der Brust", "Squeeze oben halten", "Langsam oeffnen"] },
  { id: "ex_seated_calf_raise", name: "Seated Calf Raise", category: "Machine", muscle: "Legs", source: "base", inputType: "kg_reps", howto: ["Knie unter Pad", "Volle ROM: ganz runter dehnen", "Oben 1-2 Sek halten", "Langsam ablassen"] },
  // === CABLE ===
  { id: "ex_cable_row", name: "Cable Row", category: "Cable", muscle: "Back", source: "base", inputType: "kg_reps", howto: ["Brust raus, Ruecken gerade", "Griff zum Bauch ziehen", "Schulterblatter zusammen", "Arme ganz strecken beim Zurueck"] },
  { id: "ex_face_pulls", name: "Face Pulls", category: "Cable", muscle: "Shoulders", source: "base", inputType: "kg_reps", howto: ["Seil zum Gesicht ziehen", "Ellbogen hoch, hinter die Ohren", "Externe Rotation oben", "Rear Delts + Rotatorenmanschette"] },
  { id: "ex_pallof_press", name: "Pallof Press", category: "Cable", muscle: "Core", source: "base", inputType: "reps", howto: ["Seitlich zum Kabelzug stehen", "Haende vor die Brust, dann wegdruecken", "Anti-Rotation halten", "10 Reps pro Seite"] },
  // === BODYWEIGHT ===
  { id: "ex_weighted_pullups", name: "Weighted Pull-Ups", category: "Bodyweight", muscle: "Back", source: "base", inputType: "kg_reps", howto: ["Gewicht am Guertel oder zwischen Fuessen", "Dead Hang starten", "Kinn ueber Stange", "Kontrolliert ablassen, volle Streckung"] },
  { id: "ex_weighted_dips", name: "Weighted Dips", category: "Bodyweight", muscle: "Chest", source: "base", inputType: "kg_reps", howto: ["Leichte Vorlage fuer Brust", "90 Grad in den Ellbogen", "Kontrolliert hoch", "Kein Schwung"] },
  { id: "ex_nordic_hamstring_curl", name: "Nordic Hamstring Curl", category: "Bodyweight", muscle: "Legs", source: "base", inputType: "reps", howto: ["Knie auf Pad, Fuesse fixiert", "Langsam nach vorne fallen lassen", "Hamstrings bremsen die Bewegung", "Mit Haenden abfangen, hoch druecken"] },
  { id: "ex_pistol_squat", name: "Pistol Squat (Weighted)", category: "Bodyweight", muscle: "Legs", source: "base", inputType: "kg_reps", howto: ["Ein Bein vorne gestreckt", "Langsam runter, Ferse am Boden", "Aufrecht bleiben", "Reps pro Seite"] },
  { id: "ex_explosive_pushups", name: "Explosive Push-Ups", category: "Bodyweight", muscle: "Chest", source: "base", inputType: "reps", howto: ["Normaler Push-Up Start", "Explosiv hoch, Haende vom Boden", "Weich landen", "Volle ROM"] },
  { id: "ex_hanging_leg_raise", name: "Hanging Leg Raise", category: "Bodyweight", muscle: "Core", source: "base", inputType: "reps", howto: ["Dead Hang, Schultern aktiv", "Beine gestreckt nach oben", "Becken kippen fuer volle Kontraktion", "Kein Schwung nutzen"] },
  { id: "ex_dragon_flags", name: "Dragon Flags", category: "Bodyweight", muscle: "Core", source: "base", inputType: "reps", howto: ["Auf Bank liegen, Kante greifen", "Koerper gerade nach oben", "Langsam ablassen, Koerper steif", "Nicht im unteren Ruecken durchhaengen"] },
  { id: "ex_dead_bugs", name: "Dead Bugs", category: "Bodyweight", muscle: "Core", source: "base", inputType: "reps", howto: ["Ruecken flach auf Boden", "Gegenueber Arm/Bein strecken", "Unterer Ruecken bleibt am Boden", "12 Reps pro Seite, langsam"] },
  { id: "ex_unilateral_calf_raise", name: "Unilateral Calf Raise (Standing)", category: "Bodyweight", muscle: "Legs", source: "base", inputType: "reps", howto: ["Auf Stufe stehen, ein Bein", "Ferse ganz runter dehnen", "Hoch druecken, oben halten", "Pro Seite"] },
  // === PLYOMETRICS ===
  { id: "ex_pogostick_hops", name: "Pogostick Hops", category: "Bodyweight", muscle: "Legs", source: "base", inputType: "reps", howto: ["Steife Knoechel, kurzer Bodenkontakt", "Aus den Waden springen", "15 Kontakte = 1 Set", "Schnell und rhythmisch"] },
  { id: "ex_single_leg_bounds", name: "Single-Leg Bounds", category: "Bodyweight", muscle: "Legs", source: "base", inputType: "reps", howto: ["Einbeinig abspruengen, weit nach vorne", "Knie hoch, aktiver Armeinsatz", "5 Kontakte pro Seite = 1 Set", "Maximale Weite pro Sprung"] },
  { id: "ex_box_jumps", name: "Box Jumps", category: "Bodyweight", muscle: "Legs", source: "base", inputType: "reps", howto: ["Schulterbreiter Stand vor Box", "Armschwung nutzen", "Beidbeinig landen, Knie weich", "Runtersteigen, nicht springen"] },
  { id: "ex_drop_jumps", name: "Drop Jumps (30-40cm)", category: "Bodyweight", muscle: "Legs", source: "base", inputType: "reps", howto: ["Von Box fallen lassen, nicht springen", "Sofort reaktiv hochspringen", "Minimaler Bodenkontakt", "Erst ab Woche 9"] },
  // === PREHAB / BANDS ===
  { id: "ex_banded_lateral_walks", name: "Banded Lateral Walks", category: "Other", muscle: "Legs", source: "base", inputType: "reps", howto: ["Band um Knoechel oder Knie", "Leicht in die Hocke", "Seitlich gehen, Spannung halten", "12 Schritte pro Seite"] },
  { id: "ex_banded_marches", name: "Banded Marches (Hip Flexor)", category: "Other", muscle: "Legs", source: "base", inputType: "reps", howto: ["Band um Fuesse", "Knie abwechselnd hochziehen", "Aufrecht stehen", "10 pro Seite"] },
  { id: "ex_tibialis_raises", name: "Tibialis Raises", category: "Other", muscle: "Legs", source: "base", inputType: "reps", howto: ["Ruecken an Wand lehnen", "Zehen hochziehen", "Langsam ablassen", "Schienbeinmuskel kraeftigen"] },
  { id: "ex_short_foot", name: "Short Foot Exercise", category: "Other", muscle: "Legs", source: "base", inputType: "time_sec", howto: ["Barfuss stehen", "Fussgewoelbe aktiv anspannen", "Zehen bleiben am Boden", "30 Sek pro Fuss halten"] },
  { id: "ex_band_pull_aparts", name: "Band Pull-Aparts", category: "Other", muscle: "Shoulders", source: "base", inputType: "reps", howto: ["Band vor der Brust halten", "Arme gestreckt auseinanderziehen", "Schulterblatter zusammen", "20 Reps, leichtes Band"] },
  // === WARMUP / MOBILITY ===
  { id: "ex_rower_warmup", name: "Rower (Warmup)", category: "Machine", muscle: "Full Body", source: "base", inputType: "duration", howto: ["5 Min locker rudern", "Herzfrequenz langsam hochfahren", "Fokus auf Technik"] },
  { id: "ex_skierg_warmup", name: "SkiErg (Warmup)", category: "Machine", muscle: "Full Body", source: "base", inputType: "duration", howto: ["3-5 Min locker ziehen", "Ganzer Koerper, lockere Arme", "Aufwaermen, nicht auspowern"] },
  { id: "ex_hip_opener", name: "Hip Opener (Dynamic)", category: "Other", muscle: "Legs", source: "base", inputType: "check", howto: ["90/90 Stretch", "World's Greatest Stretch", "Huefte in alle Richtungen oeffnen"] },
  { id: "ex_banded_glute_activation", name: "Banded Glute Activation", category: "Other", muscle: "Legs", source: "base", inputType: "check", howto: ["Band ueber den Knien", "Clamshells + Glute Bridges", "Gluteus aktivieren vor Squats"] },
  { id: "ex_dynamic_lunges", name: "Dynamic Lunges (Warmup)", category: "Bodyweight", muscle: "Legs", source: "base", inputType: "check", howto: ["Abwechselnd vorwaerts/rueckwaerts", "Grosser Schritt, Knie 90 Grad", "Dynamisch, nicht statisch halten"] },
  { id: "ex_shoulder_circles", name: "Shoulder Circles", category: "Other", muscle: "Shoulders", source: "base", inputType: "check", howto: ["Arme kreisen, klein zu gross", "Vorwaerts und rueckwaerts", "Schultergelenk mobilisieren"] },
  { id: "ex_pushup_walkouts", name: "Push-Up Walkouts", category: "Bodyweight", muscle: "Chest", source: "base", inputType: "check", howto: ["Stehend nach vorne laufen mit Haenden", "Push-Up Position, 1-2 Push-Ups", "Zurueck laufen, aufstehen", "5-8 Wiederholungen"] },
  { id: "ex_ankle_hops", name: "Ankle Hops", category: "Bodyweight", muscle: "Legs", source: "base", inputType: "reps", howto: ["Kleine schnelle Spruenge", "Aus den Knoecheln, steife Knie", "Bodenkontakt minimieren", "2x10 Reps"] },
  { id: "ex_a_skips", name: "A-Skips", category: "Bodyweight", muscle: "Legs", source: "base", inputType: "dist", howto: ["Knie hoch, aktiver Fussaufsatz", "Arme gegenueber mitfuehren", "2x20m", "Lauftechnik-Drill"] },
  { id: "ex_dynamic_stretching", name: "Dynamic Stretching", category: "Other", muscle: "Full Body", source: "base", inputType: "check", howto: ["Bein-Pendel vorwaerts/seitwaerts", "Arm-Kreise", "Rumpfrotation", "Jede Bewegung 10x"] },
  { id: "ex_skierg_finisher", name: "SkiErg Anaerobic (Finisher)", category: "Machine", muscle: "Full Body", source: "base", inputType: "duration", howto: ["8x30 Sek All-Out", "30 Sek Pause dazwischen", "Maximale Power pro Intervall", "Insgesamt ca. 8 Min"] },
  // === V5 NEW ===
  { id: "ex_hanging_knee_raise", name: "Hanging Knee Raises", category: "Bodyweight", muscle: "Core", source: "base", inputType: "reps", howto: ["Dead Hang, Schultern aktiv", "Knie zur Brust ziehen", "Becken kippen fuer Kontraktion", "Kein Schwung, kontrolliert"] },
  { id: "ex_cable_woodchops", name: "Cable Woodchops", category: "Cable", muscle: "Core", source: "base", inputType: "reps", howto: ["Kabel oben oder unten ansetzen", "Rotation aus der Hueftee", "Arme gestreckt, Core dreht", "10 Reps pro Seite, kontrolliert"] },
  { id: "ex_copenhagen_plank", name: "Copenhagen Plank", category: "Bodyweight", muscle: "Core", source: "base", inputType: "time_sec", howto: ["Seitlage, oberes Bein auf Bank", "Unteres Bein frei, Hufte heben", "Adduktoren + Core gleichzeitig", "15-20 Sek pro Seite"] },
  { id: "ex_lateral_raises", name: "Lateral Raises", category: "Dumbbell", muscle: "Shoulders", source: "base", inputType: "kg_reps", howto: ["Leichte DBs, leichte Vorlage", "Arme seitlich bis Schulterhoehe", "Kleiner Finger oben, kontrolliert", "Schulter-Breite und Aesthetik"] },
];

const CATEGORIES = ["All", "Machine", "Barbell", "Dumbbell", "Cable", "Bodyweight", "Other"];
const MUSCLES = ["All", "Chest", "Back", "Legs", "Shoulders", "Arms", "Core", "Full Body", "Other"];

/** =========================
 * PRE-BUILT Training Plans from Trainingsplan
 * ========================= */
function makeSet(targetKg, repMin, repMax, rir) {
  return { targetKg: targetKg || "", targetReps: "", targetRepMin: String(repMin), targetRepMax: String(repMax), targetRir: String(rir || "") };
}
function makePlanItem(exerciseId, sets, opts = {}) {
  return {
    id: `pi_${exerciseId}_${Math.random().toString(16).slice(2,8)}`,
    exerciseId,
    section: opts.section || "",
    progressionMode: opts.mode || "double",
    loadRule: "range_then_load",
    incrementKg: opts.inc ?? 2.5,
    fixedReps: opts.fixedReps || "5",
    backoffPercent: "12",
    deloadEnabled: false,
    sets,
  };
}

const DEFAULT_PLAN_LOWER = {
  id: "plan_v5_lower",
  name: "Di - Lower Body + Core",
  restDefaultSeconds: 180,
  items: [
    makePlanItem("ex_hip_opener", [makeSet("", 1, 1, "")], { inc: 0, section: "Aufwaermen" }),
    makePlanItem("ex_banded_glute_activation", [makeSet("", 1, 1, "")], { inc: 0, section: "Aufwaermen" }),
    makePlanItem("ex_trap_bar_deadlift", [makeSet("", 4, 6, 2), makeSet("", 4, 6, 2), makeSet("", 4, 6, 2), makeSet("", 4, 6, 2)], { inc: 2.5, section: "Kraft" }),
    makePlanItem("ex_back_squat", [makeSet("", 4, 6, 2), makeSet("", 4, 6, 2), makeSet("", 4, 6, 2), makeSet("", 4, 6, 2)], { inc: 2.5, section: "Kraft" }),
    makePlanItem("ex_rdl", [makeSet("", 6, 8, 2), makeSet("", 6, 8, 2), makeSet("", 6, 8, 2)], { inc: 2.5, section: "Kraft" }),
    makePlanItem("ex_bulgarian_split_squat", [makeSet("", 8, 8, 2), makeSet("", 8, 8, 2), makeSet("", 8, 8, 2)], { inc: 1, section: "Kraft" }),
    makePlanItem("ex_nordic_hamstring_curl", [makeSet("", 4, 6, 2), makeSet("", 4, 6, 2), makeSet("", 4, 6, 2)], { inc: 0, section: "Kraft" }),
    makePlanItem("ex_unilateral_calf_raise", [makeSet("", 12, 15, 1), makeSet("", 12, 15, 1), makeSet("", 12, 15, 1)], { inc: 0, section: "Kraft" }),
    makePlanItem("ex_seated_calf_raise", [makeSet("", 15, 20, 1), makeSet("", 15, 20, 1)], { inc: 2.5, section: "Kraft" }),
    makePlanItem("ex_hanging_knee_raise", [makeSet("", 12, 12, ""), makeSet("", 12, 12, ""), makeSet("", 12, 12, "")], { inc: 0, section: "Core" }),
    makePlanItem("ex_dead_bugs", [makeSet("", 10, 10, ""), makeSet("", 10, 10, ""), makeSet("", 10, 10, "")], { inc: 0, section: "Core" }),
    makePlanItem("ex_pallof_press", [makeSet("", 8, 8, ""), makeSet("", 8, 8, ""), makeSet("", 8, 8, "")], { inc: 0, section: "Core" }),
  ],
};

const DEFAULT_PLAN_PULL = {
  id: "plan_v5_pull",
  name: "Fr - Pull + VO2max + Core",
  restDefaultSeconds: 150,
  items: [
    makePlanItem("ex_shoulder_circles", [makeSet("", 1, 1, "")], { inc: 0, section: "Aufwaermen" }),
    makePlanItem("ex_band_pull_aparts", [makeSet("", 15, 15, "")], { inc: 0, section: "Aufwaermen" }),
    makePlanItem("ex_weighted_pullups", [makeSet("", 4, 6, 2), makeSet("", 4, 6, 2), makeSet("", 4, 6, 2), makeSet("", 4, 6, 2)], { inc: 1, section: "Pull" }),
    makePlanItem("ex_barbell_rows", [makeSet("", 6, 8, 2), makeSet("", 6, 8, 2), makeSet("", 6, 8, 2)], { inc: 2.5, section: "Pull" }),
    makePlanItem("ex_face_pulls", [makeSet("", 15, 15, 1), makeSet("", 15, 15, 1), makeSet("", 15, 15, 1)], { inc: 1.25, section: "Pull" }),
    makePlanItem("ex_incline_db_curl", [makeSet("", 8, 10, 1), makeSet("", 8, 10, 1)], { inc: 1, section: "Pull" }),
    makePlanItem("ex_farmer_walks", [makeSet("", 1, 1, ""), makeSet("", 1, 1, ""), makeSet("", 1, 1, "")], { inc: 2.5, section: "Pull" }),
    makePlanItem("ex_rower_warmup", [makeSet("", 20, 20, "")], { inc: 0, section: "VO2max Rower" }),
    makePlanItem("ex_hanging_leg_raise", [makeSet("", 8, 10, ""), makeSet("", 8, 10, ""), makeSet("", 8, 10, "")], { inc: 0, section: "Core" }),
    makePlanItem("ex_dragon_flags", [makeSet("", 5, 6, ""), makeSet("", 5, 6, ""), makeSet("", 5, 6, "")], { inc: 0, section: "Core" }),
    makePlanItem("ex_pallof_press", [makeSet("", 8, 8, ""), makeSet("", 8, 8, ""), makeSet("", 8, 8, "")], { inc: 0, section: "Core" }),
  ],
};

const DEFAULT_PLAN_PUSH = {
  id: "plan_v5_push",
  name: "Sa PM - Push + Core + SkiErg",
  restDefaultSeconds: 120,
  items: [
    makePlanItem("ex_shoulder_circles", [makeSet("", 1, 1, "")], { inc: 0, section: "Aufwaermen" }),
    makePlanItem("ex_pushup_walkouts", [makeSet("", 1, 1, "")], { inc: 0, section: "Aufwaermen" }),
    makePlanItem("ex_incline_db_press", [makeSet("", 5, 6, 2), makeSet("", 5, 6, 2), makeSet("", 5, 6, 2)], { inc: 1, section: "Push" }),
    makePlanItem("ex_overhead_press", [makeSet("", 5, 6, 2), makeSet("", 5, 6, 2), makeSet("", 5, 6, 2)], { inc: 2.5, section: "Push" }),
    makePlanItem("ex_weighted_dips", [makeSet("", 6, 8, 2), makeSet("", 6, 8, 2)], { inc: 1, section: "Push" }),
    makePlanItem("ex_chest_fly_machine", [makeSet("", 8, 10, 1)], { inc: 2.5, section: "Push" }),
    makePlanItem("ex_lateral_raises", [makeSet("", 12, 15, 1), makeSet("", 12, 15, 1), makeSet("", 12, 15, 1)], { inc: 1, section: "Push" }),
    makePlanItem("ex_dragon_flags", [makeSet("", 6, 6, ""), makeSet("", 6, 6, ""), makeSet("", 6, 6, "")], { inc: 0, section: "Core" }),
    makePlanItem("ex_cable_woodchops", [makeSet("", 10, 10, ""), makeSet("", 10, 10, ""), makeSet("", 10, 10, "")], { inc: 0, section: "Core" }),
    makePlanItem("ex_dead_bugs", [makeSet("", 10, 10, ""), makeSet("", 10, 10, ""), makeSet("", 10, 10, "")], { inc: 0, section: "Core" }),
    makePlanItem("ex_skierg_finisher", [makeSet("", 8, 8, "")], { inc: 0, section: "Finisher" }),
  ],
};

const DEFAULT_PLAN_PLYO = {
  id: "plan_v5_plyo",
  name: "So - Plyo + Prehab + Core",
  restDefaultSeconds: 90,
  items: [
    makePlanItem("ex_skierg_warmup", [makeSet("", 5, 5, "")], { inc: 0, section: "Aufwaermen" }),
    makePlanItem("ex_dynamic_stretching", [makeSet("", 1, 1, "")], { inc: 0, section: "Aufwaermen" }),
    makePlanItem("ex_ankle_hops", [makeSet("", 10, 10, ""), makeSet("", 10, 10, "")], { inc: 0, section: "Aufwaermen" }),
    makePlanItem("ex_a_skips", [makeSet("", 1, 1, ""), makeSet("", 1, 1, "")], { inc: 0, section: "Aufwaermen" }),
    makePlanItem("ex_pogostick_hops", [makeSet("", 15, 15, ""), makeSet("", 15, 15, ""), makeSet("", 15, 15, "")], { inc: 0, section: "Plyometrics" }),
    makePlanItem("ex_single_leg_bounds", [makeSet("", 5, 5, ""), makeSet("", 5, 5, ""), makeSet("", 5, 5, "")], { inc: 0, section: "Plyometrics" }),
    makePlanItem("ex_box_jumps", [makeSet("", 5, 5, ""), makeSet("", 5, 5, ""), makeSet("", 5, 5, "")], { inc: 0, section: "Plyometrics" }),
    makePlanItem("ex_drop_jumps", [makeSet("", 4, 4, ""), makeSet("", 4, 4, ""), makeSet("", 4, 4, "")], { inc: 0, section: "Plyometrics" }),
    makePlanItem("ex_banded_lateral_walks", [makeSet("", 12, 12, ""), makeSet("", 12, 12, ""), makeSet("", 12, 12, "")], { inc: 0, section: "Prehab" }),
    makePlanItem("ex_banded_marches", [makeSet("", 10, 10, ""), makeSet("", 10, 10, ""), makeSet("", 10, 10, "")], { inc: 0, section: "Prehab" }),
    makePlanItem("ex_tibialis_raises", [makeSet("", 15, 20, ""), makeSet("", 15, 20, ""), makeSet("", 15, 20, "")], { inc: 0, section: "Prehab" }),
    makePlanItem("ex_short_foot", [makeSet("", 30, 30, ""), makeSet("", 30, 30, "")], { inc: 0, section: "Prehab" }),
    makePlanItem("ex_seated_calf_raise", [makeSet("", 15, 20, 1), makeSet("", 15, 20, 1)], { inc: 2.5, section: "Prehab" }),
    makePlanItem("ex_hanging_leg_raise", [makeSet("", 10, 10, ""), makeSet("", 10, 10, ""), makeSet("", 10, 10, ""), makeSet("", 10, 10, "")], { inc: 0, section: "Core Fokus" }),
    makePlanItem("ex_dragon_flags", [makeSet("", 6, 8, ""), makeSet("", 6, 8, ""), makeSet("", 6, 8, "")], { inc: 0, section: "Core Fokus" }),
    makePlanItem("ex_pallof_press", [makeSet("", 10, 10, ""), makeSet("", 10, 10, ""), makeSet("", 10, 10, "")], { inc: 0, section: "Core Fokus" }),
    makePlanItem("ex_copenhagen_plank", [makeSet("", 15, 20, ""), makeSet("", 15, 20, "")], { inc: 0, section: "Core Fokus" }),
  ],
};

const DEFAULT_PLANS = [DEFAULT_PLAN_LOWER, DEFAULT_PLAN_PULL, DEFAULT_PLAN_PUSH, DEFAULT_PLAN_PLYO];

/** Pre-built Endurance Templates V5 */
const DEFAULT_ENDURANCE_TEMPLATES = [
  {
    id: "endtpl_v5_recovery",
    name: "Recovery Run - Zone 1-2",
    sportType: "Run",
    workoutType: "Recovery",
    target: { durationMin: 30, distanceKm: undefined },
    intervals: undefined,
    notes: "Wo 1-4: 30 Min, Wo 5-8: 35 Min, Wo 9-12: 35-40 Min. Pace 6:00-6:30/km. Nase-Atmen-Test.",
    createdAt: Date.now(), updatedAt: Date.now(),
  },
  {
    id: "endtpl_v5_quality",
    name: "Quality Run + Plyo-Drills",
    sportType: "Run",
    workoutType: "Tempo",
    target: { durationMin: 55, distanceKm: undefined },
    intervals: [
      { id: "qi1", kind: "work", durationSec: 600, targetText: "Einlaufen locker" },
      { id: "qi2", kind: "work", durationSec: 1200, targetText: "Tempo 4:45-5:00/km" },
      { id: "qi3", kind: "rest", durationSec: 600, targetText: "Auslaufen + 4-6x 80m Strides" },
    ],
    notes: "Plyo-Warmup: 10x Pogo + 5x Bounds/Seite + A-Skips 2x20m. Protokoll rotiert: Tempo/Intervalle/Fartlek/Deload.",
    createdAt: Date.now(), updatedAt: Date.now(),
  },
  {
    id: "endtpl_v5_long",
    name: "Long Run - Zone 2",
    sportType: "Run",
    workoutType: "Long",
    target: { durationMin: 60, distanceKm: undefined },
    intervals: undefined,
    notes: "Plyo-Warmup: 10x Pogo + 4x Bounds/Seite + A-Skips 1x20m. Zone 2. Wo 1-2: 60min, Wo 5-6: 75min, Wo 9-10: 90min, Wo 11-12: 95-100min. Min. 6h Pause vor Push Day!",
    createdAt: Date.now(), updatedAt: Date.now(),
  },
  {
    id: "endtpl_v5_vo2max",
    name: "VO2max Rower (nach Pull Day)",
    sportType: "Other",
    workoutType: "Intervals",
    target: { durationMin: 20, distanceKm: undefined },
    intervals: [
      { id: "vi1", kind: "work", durationSec: 240, targetText: "90% HRmax" },
      { id: "vi2", kind: "rest", durationSec: 180, targetText: "aktive Pause" },
      { id: "vi3", kind: "work", durationSec: 240, targetText: "90% HRmax" },
      { id: "vi4", kind: "rest", durationSec: 180, targetText: "aktive Pause" },
      { id: "vi5", kind: "work", durationSec: 240, targetText: "90% HRmax" },
      { id: "vi6", kind: "rest", durationSec: 180, targetText: "aktive Pause" },
      { id: "vi7", kind: "work", durationSec: 240, targetText: "90% HRmax" },
    ],
    notes: "Ungerade Wo: 4x4 Min @90% HRmax, 3 Min Pause. Gerade Wo: 6x500m <1:50, 90s Pause. Rower = Zugbewegung, perfekte Synergie mit Pull Day.",
    createdAt: Date.now(), updatedAt: Date.now(),
  },
];

/** Pre-built Calendar Templates V5 */
const DEFAULT_CALENDAR_TEMPLATES = [
  { id: "ctpl_v5_mo", title: "Recovery Run + Stretching", sportType: "Run", weekday: 1, startTime: "07:00", durationMin: 35, planId: null, notes: "Quasi-Ruhetag. Zone 1-2, Nase-Atmen-Test. + 15 Min Stretching.", active: true, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "ctpl_v5_di", title: "Lower Body + Core", sportType: "Gym", weekday: 2, startTime: "16:00", durationMin: 65, planId: "plan_v5_lower", notes: "Ramping Sets: Leere Stange x8 > 40% x5 > 60% x3 > Arbeitssaetze. ~65 Min.", active: true, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "ctpl_v5_mi", title: "Quality Run + Plyo-Drills", sportType: "Run", weekday: 3, startTime: "16:00", durationMin: 55, planId: null, notes: "Plyo-Warmup, 10 Min einlaufen, dann Tempo/Intervalle. + 4-6x 80m Strides.", active: true, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "ctpl_v5_do", title: "Schulsport + Volleyball", sportType: "Other", weekday: 4, startTime: "14:00", durationMin: 60, planId: null, notes: "Cross-Training. Kein extra Training.", active: true, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "ctpl_v5_fr", title: "Pull + VO2max + Core", sportType: "Gym", weekday: 5, startTime: "16:00", durationMin: 75, planId: "plan_v5_pull", notes: "Pull Day: Alle Zugbewegungen. Rower VO2max danach. Core-Block am Ende. ~75 Min.", active: true, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "ctpl_v5_sa_am", title: "Long Run - Zone 2", sportType: "Run", weekday: 6, startTime: "08:00", durationMin: 60, planId: null, notes: "Plyo-Warmup. Zone 2. Min. 6h Pause + Mahlzeit vor Push Day!", active: true, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "ctpl_v5_sa_pm", title: "Push + Core + SkiErg", sportType: "Gym", weekday: 6, startTime: "15:00", durationMin: 65, planId: "plan_v5_push", notes: "Push Day: Press, Dips, Laterals. Core-Block. SkiErg 8x30s Finisher. ~60-65 Min.", active: true, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "ctpl_v5_so", title: "Plyo + Prehab + Core", sportType: "Gym", weekday: 7, startTime: "10:00", durationMin: 60, planId: "plan_v5_plyo", notes: "FRISCHE BEINE! 4+ Tage seit Lower Body. Plyo zuerst, dann Prehab, dann Core-Fokus (intensivster Core-Tag). ~60 Min.", active: true, createdAt: Date.now(), updatedAt: Date.now() },
];


/** =========================
 * Storage
 * ========================= */
const STORAGE_KEY = "gymapp_state_v3";
const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || "";
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || "";
const supabase = SUPABASE_URL && SUPABASE_ANON_KEY ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

/** =========================
 * Helpers
 * ========================= */
function uid() { return Math.random().toString(16).slice(2) + Date.now().toString(16); }
function formatMMSS(totalSeconds) { const m = Math.floor(totalSeconds / 60); const s = totalSeconds % 60; return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`; }
function minutesBetween(a, b) { return Math.max(1, Math.round((b - a) / 60000)); }
function normalizeKey(ex) { return `${(ex.name||"").trim().toLowerCase()}__${(ex.category||"").trim().toLowerCase()}__${(ex.muscle||"").trim().toLowerCase()}`; }
function safeJsonParse(text) { try { return { ok: true, value: JSON.parse(text) }; } catch (e) { return { ok: false, error: String(e?.message || e) }; } }
function makeJoinCode(len = 8) { const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let out = ""; for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)]; return out; }
const SPORT_TYPES = ["Gym", "Run", "Bike", "Swim", "Other"];
function pad2(n) { return String(n).padStart(2, "0"); }
function formatDateKey(d) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }
function parseDateKey(key) { const m = String(key || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); if (!m) return null; const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])); return Number.isNaN(d.getTime()) ? null : d; }
function parseTimeToMin(hhmm) { const m = String(hhmm || "").match(/^(\d{2}):(\d{2})$/); if (!m) return 0; return Number(m[1]) * 60 + Number(m[2]); }
function startOfWeekMonday(d) { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); const wd = x.getDay(); const delta = wd === 0 ? -6 : 1 - wd; x.setDate(x.getDate() + delta); return x; }
function addDays(d, n) { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() + n); return x; }
function getWeekRangeLabel(weekStart) { const end = addDays(weekStart, 6); return `${weekStart.toLocaleDateString(undefined, { month: "short", day: "numeric" })} - ${end.toLocaleDateString(undefined, { month: "short", day: "numeric" })}`; }
function weekdayMonday1to7(d) { const wd = d.getDay(); return wd === 0 ? 7 : wd; }

function normalizeCalendarEntry(raw) {
  const d = parseDateKey(raw?.date) ? raw.date : formatDateKey(new Date());
  return { id: raw?.id || uid(), date: d, startTime: raw?.startTime || "07:00", durationMin: Math.max(1, parseInt(String(raw?.durationMin || 45), 10) || 45), title: raw?.title || raw?.label || "Entry", sportType: raw?.sportType || "Other", planId: raw?.planId || null, status: raw?.status || "planned", templateId: raw?.templateId || null, createdAt: raw?.createdAt || Date.now(), updatedAt: raw?.updatedAt || Date.now() };
}
function normalizeCalendarTemplate(raw) {
  return { id: raw?.id || uid(), title: raw?.title || "Template", sportType: raw?.sportType || "Other", weekday: Math.min(7, Math.max(1, parseInt(String(raw?.weekday || 1), 10) || 1)), startTime: raw?.startTime || "07:00", durationMin: Math.max(1, parseInt(String(raw?.durationMin || 45), 10) || 45), planId: raw?.planId || null, notes: raw?.notes || "", active: raw?.active !== false, createdAt: raw?.createdAt || Date.now(), updatedAt: raw?.updatedAt || Date.now() };
}

const DEFAULT_PREFS = {
  defaultRestSeconds: 180,
  defaultRepRange: { min: 6, max: 10 },
  increments: { Barbell: 2.5, Dumbbell: 1, Machine: 2.5, Cable: 1.25, Bodyweight: 0, Other: 1 },
  autoFillFromLastSession: true,
  communityEnabled: false,
  communityVisibility: "private",
  communityApproveRequired: true,
  exerciseDefaultsOverrides: {},
  exerciseSetupOverrides: {},
  localTipsByExercise: {},
};
function normalizePrefs(raw) {
  const p0 = raw && typeof raw === "object" ? raw : {};
  const out = { ...DEFAULT_PREFS, ...p0, defaultRepRange: { min: Number(p0?.defaultRepRange?.min ?? DEFAULT_PREFS.defaultRepRange.min), max: Number(p0?.defaultRepRange?.max ?? DEFAULT_PREFS.defaultRepRange.max) }, increments: { ...DEFAULT_PREFS.increments, ...(p0?.increments || {}) } };
  if (!out.communityVisibility || !["private", "friends"].includes(out.communityVisibility)) out.communityVisibility = "private";
  return out;
}
function normalizePerformedSet(s) {
  const kgMissing = String(s?.kg ?? "").trim() === "";
  const repsMissing = String(s?.reps ?? "").trim() === "";
  return { ...s, kg: String(s?.kg ?? ""), reps: String(s?.reps ?? ""), note: s?.note || "", missing: Boolean(s?.missing || kgMissing || repsMissing) };
}
function normalizeGymSession(session) {
  const items = (session?.items || []).map((it) => ({ ...it, exerciseNote: it?.exerciseNote || "", performed: (it?.performed || []).map(normalizePerformedSet) }));
  const hasMissing = items.some((it) => it.performed.some((x) => x.missing));
  return { ...session, status: session?.status || (hasMissing ? "incomplete" : "complete"), items };
}
function isSessionComplete(items) {
  for (const it of items || []) { for (const s of it.performed || []) { if (String(s?.kg || "").trim() === "" || String(s?.reps || "").trim() === "") return false; } } return true;
}

const FREE_EXERCISE_DB_URL = "https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/dist/exercises.json";
function mapEquipmentToCategory(equipment) { const e = String(equipment || "").toLowerCase(); if (e.includes("machine")) return "Machine"; if (e.includes("barbell")) return "Barbell"; if (e.includes("dumbbell")) return "Dumbbell"; if (e.includes("cable")) return "Cable"; if (e.includes("body")) return "Bodyweight"; return "Other"; }
function mapPrimaryMuscleToGroup(primaryMuscles) { const m = String((primaryMuscles && primaryMuscles[0]) || "").toLowerCase(); if (m.includes("ab") || m.includes("oblique")) return "Core"; if (m.includes("chest") || m.includes("pect")) return "Chest"; if (m.includes("back") || m.includes("lat") || m.includes("trap")) return "Back"; if (m.includes("quad") || m.includes("ham") || m.includes("calf") || m.includes("glute") || m.includes("adductor") || m.includes("abductor")) return "Legs"; if (m.includes("shoulder") || m.includes("deltoid")) return "Shoulders"; if (m.includes("bicep") || m.includes("tricep") || m.includes("forearm")) return "Arms"; return "Other"; }

const SEARCH_SYNONYMS = { ohp: ["overhead", "press"], rdl: ["romanian", "deadlift"], bp: ["bench", "press"], lp: ["leg", "press"], abs: ["abs", "abdominals", "core"], quads: ["quads", "quadriceps"], hams: ["hams", "hamstrings"], tris: ["tris", "triceps"], bis: ["bis", "biceps"], db: ["dumbbell"], bb: ["barbell"] };
function tokenize(q) { const s = q.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim(); return s ? s.split(/\s+/).filter(Boolean) : []; }
function expandTokens(tokens) { const out = []; for (const t of tokens) { out.push(t); if (SEARCH_SYNONYMS[t]) out.push(...SEARCH_SYNONYMS[t]); } return Array.from(new Set(out)); }
function exerciseHaystack(ex) { const parts = [ex.name, ex.category, ex.muscle]; if (ex.meta?.equipment) parts.push(ex.meta.equipment); if (Array.isArray(ex.meta?.primaryMuscles)) parts.push(ex.meta.primaryMuscles.join(" ")); return parts.join(" ").toLowerCase(); }
function scoreExercise(ex, raw, tokens) { if (!raw) return 0; const name = ex.name.toLowerCase(); const cat = ex.category.toLowerCase(); const mus = ex.muscle.toLowerCase(); const eq = String(ex.meta?.equipment || "").toLowerCase(); let s = 0; if (name === raw) s += 1400; if (name.startsWith(raw)) s += 900; if (name.includes(raw)) s += 500; for (const t of tokens) { if (!t) continue; if (name.startsWith(t)) s += 220; if (name.includes(t)) s += 140; if (mus.includes(t)) s += 90; if (cat.includes(t)) s += 90; if (eq.includes(t)) s += 60; } s += Math.max(0, 30 - Math.min(30, Math.floor(name.length / 4))); return s; }
function smartSearch(exercises, query, cat, mus, limit = 80) { const raw = query.trim().toLowerCase(); const tokens = expandTokens(tokenize(raw)); const filtered = []; for (const ex of exercises) { if (cat && cat !== "All" && ex.category !== cat) continue; if (mus && mus !== "All" && ex.muscle !== mus) continue; if (!raw) { filtered.push({ ex, s: 0 }); continue; } const hay = exerciseHaystack(ex); const ok = hay.includes(raw) || tokens.some((t) => (t.length <= 1 ? false : hay.includes(t))); if (!ok) continue; filtered.push({ ex, s: scoreExercise(ex, raw, tokens) }); } filtered.sort((a, b) => { if (!raw) return a.ex.name.localeCompare(b.ex.name); if (b.s !== a.s) return b.s - a.s; return a.ex.name.localeCompare(b.ex.name); }); return filtered.slice(0, limit).map((x) => x.ex); }

function toNum(v) { const n = parseFloat(String(v ?? "").replace(",", ".")); return Number.isFinite(n) ? n : 0; }
function getIncrementByCategory(category) { if (category === "Barbell") return 2.5; if (category === "Dumbbell") return 1; if (category === "Machine") return 2.5; if (category === "Bodyweight") return 0; return 1; }
function formatRunPace(durationMin, distanceKm) { const d = toNum(distanceKm); const t = toNum(durationMin); if (d <= 0 || t <= 0) return "-"; const p = t / d; const m = Math.floor(p); const sec = Math.round((p - m) * 60); return `${m}:${pad2(sec)} min/km`; }
function formatBikeSpeed(durationMin, distanceKm) { const d = toNum(distanceKm); const t = toNum(durationMin); if (d <= 0 || t <= 0) return "-"; return `${(d / (t / 60)).toFixed(1)} km/h`; }
function formatSwimPace(durationMin, distanceKm) { const dKm = toNum(distanceKm); const t = toNum(durationMin); const meters = dKm * 1000; if (meters <= 0 || t <= 0) return "-"; const per100 = t / (meters / 100); const m = Math.floor(per100); const sec = Math.round((per100 - m) * 60); return `${m}:${pad2(sec)} /100m`; }
function enduranceMetricLabel(sportType, durationMin, distanceKm) { if (sportType === "Run") return formatRunPace(durationMin, distanceKm); if (sportType === "Bike") return formatBikeSpeed(durationMin, distanceKm); if (sportType === "Swim") return formatSwimPace(durationMin, distanceKm); return "-"; }

function evaluateSetSuggestion(item, setEntry, allSets, setIdx) {
  const reps = toNum(setEntry?.reps); const kg = toNum(setEntry?.kg); const rir = toNum(setEntry?.rir);
  const repMin = toNum(setEntry?.targetRepMin || 0) || 6; const repMax = toNum(setEntry?.targetRepMax || 0) || Math.max(repMin, 10);
  const inc = toNum(item?.incrementKg || 0) || 1; const mode = item?.progressionMode || "double";
  if (mode === "top_backoff") { if (setIdx === 0) { if (reps >= repMax) return `Next backoff: ${Math.max(0, kg * (1 - (toNum(item?.backoffPercent) || 10) / 100)).toFixed(1)} kg`; if (reps < repMin) return "Next set: reduce 5%"; return "Next set: keep weight"; } return reps < repMin ? "Next set: reduce 5%" : "Next set: keep weight"; }
  if (mode === "fixed_load") { const fixed = toNum(item?.fixedReps || 5) || 5; if (reps >= fixed && rir >= 1) return `Next session: +${inc} kg`; if (reps < fixed - 1) return "Next set: reduce 5%"; return "Next set: keep weight"; }
  const allDone = allSets.every((x) => x?.done); const allAtTop = allSets.every((x) => toNum(x?.reps) >= repMax);
  if (reps < repMin) return "Next set: reduce 5%"; if (allDone && allAtTop) return `Next session: +${inc} kg`; return "Next set: keep weight";
}

function buildExerciseHistory(sessions) {
  const out = {};
  for (const s of sessions || []) {
    const date = formatDateKey(new Date(s.startedAt || s.endedAt || Date.now()));
    for (const it of s.items || []) {
      let bestKg = 0, bestReps = 0, totalVolume = 0;
      for (const set of it.performed || []) { const kg = toNum(set?.kg); const reps = toNum(set?.reps); if (kg <= 0 || reps <= 0) continue; bestKg = Math.max(bestKg, kg); bestReps = Math.max(bestReps, reps); totalVolume += kg * reps; }
      if (bestKg <= 0 && totalVolume <= 0) continue;
      const row = { sessionId: s.id, date, ts: Number(s.startedAt || s.endedAt || Date.now()), bestKg: Number(bestKg.toFixed(1)), bestReps, totalVolume: Number(totalVolume.toFixed(1)), est1RM: Number((bestKg * (1 + bestReps / 30)).toFixed(1)) };
      if (!out[it.exerciseId]) out[it.exerciseId] = [];
      out[it.exerciseId].push(row);
    }
  }
  for (const key of Object.keys(out)) out[key].sort((a, b) => b.ts - a.ts);
  return out;
}


/** =========================
 * UI Atoms
 * ========================= */
function GlassCard({ title, children, style }) {
  return (<View style={[styles.card, style]}>{title ? <Text style={styles.cardTitle}>{title}</Text> : null}{children}</View>);
}
function PillButton({ label, onPress, variant = "primary", accessibilityLabel }) {
  return (<Pressable accessibilityLabel={accessibilityLabel || label} onPress={onPress} style={({ pressed }) => [styles.pill, variant === "primary" ? styles.pillPrimary : styles.pillSecondary, pressed ? { opacity: 0.72, transform: [{ scale: 0.985 }] } : null]}><Text style={variant === "primary" ? styles.pillTextPrimary : styles.pillTextSecondary}>{label}</Text></Pressable>);
}
function Chip({ label, active, onPress }) {
  return (<Pressable onPress={onPress} style={[styles.chip, active ? styles.chipActive : null]}><Text style={active ? styles.chipTextActive : styles.chipText}>{label}</Text></Pressable>);
}
function TabIcon({ label, active, onPress }) {
  return (
    <Pressable onPress={onPress} hitSlop={{ top: 8, bottom: 8, left: 6, right: 6 }} style={({ pressed }) => [styles.tabBtn, active ? styles.tabBtnActive : null, pressed ? { opacity: 0.6 } : null]}>
      {active ? <View style={styles.tabDot} /> : null}
      <Text style={[styles.tabLabel, active ? styles.tabLabelActive : null]}>{label}</Text>
    </Pressable>
  );
}
function HeaderBar({ title, right }) { return (<View style={styles.rowBetween}><Text style={styles.h1}>{title}</Text>{right || null}</View>); }
function SectionDivider({ label }) {
  return (<View style={styles.sectionDivider}><View style={styles.sectionLine} /><Text style={styles.sectionLabel}>{label}</Text><View style={styles.sectionLine} /></View>);
}
function ListEmpty({ text }) { return <Text style={styles.muted}>{text}</Text>; }
function RowButton({ label, onPress, variant = "secondary", accessibilityLabel }) { return <PillButton label={label} onPress={onPress} variant={variant} accessibilityLabel={accessibilityLabel} />; }
function ToastBanner({ toast }) { if (!toast?.text) return null; return (<View style={[styles.toastWrap, toast.type === "error" ? styles.toastError : toast.type === "success" ? styles.toastSuccess : null]}><Text style={styles.toastText}>{toast.text}</Text></View>); }
function CelebrationOverlay({ visible }) {
  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => { Animated.timing(anim, { toValue: visible ? 1 : 0, duration: 260, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start(); }, [visible, anim]);
  if (!visible) return null;
  return (<Animated.View style={[styles.celebrationOverlay, { opacity: anim, transform: [{ scale: anim.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1] }) }] }]}><View style={styles.celebrationCard}><Text style={styles.h1}>Done</Text><Text style={styles.help}>Workout complete</Text></View></Animated.View>);
}
function GlowTextInput({ style, ...props }) {
  const focus = useRef(new Animated.Value(0)).current;
  const [focused, setFocused] = useState(false);
  useEffect(() => { Animated.timing(focus, { toValue: focused ? 1 : 0, duration: 180, easing: Easing.out(Easing.quad), useNativeDriver: false }).start(); }, [focused, focus]);
  const borderColor = focus.interpolate({ inputRange: [0, 1], outputRange: ["rgba(0,0,0,0.08)", "rgba(68,142,255,0.42)"] });
  return (<View style={{ position: "relative" }}><Animated.View pointerEvents="none" style={[styles.glowBlobBlue, { opacity: focus }]} /><Animated.View pointerEvents="none" style={[styles.glowBlobGreen, { opacity: focus.interpolate({ inputRange: [0, 1], outputRange: [0, 0.7] }) }]} /><Animated.View style={[styles.inputGlowWrap, { borderColor }, style]}><TextInput {...props} onFocus={(e) => { setFocused(true); props.onFocus?.(e); }} onBlur={(e) => { setFocused(false); props.onBlur?.(e); }} style={[styles.input, { borderWidth: 0, backgroundColor: "transparent", paddingHorizontal: 0, paddingVertical: 0 }, props.multiline ? { minHeight: 44, textAlignVertical: "top" } : null]} /></Animated.View></View>);
}
function PulsePressable({ children, onPress, style }) {
  const scale = useRef(new Animated.Value(1)).current;
  function doPress() { Animated.sequence([Animated.timing(scale, { toValue: 0.95, duration: 70, useNativeDriver: true }), Animated.spring(scale, { toValue: 1, friction: 4, tension: 120, useNativeDriver: true })]).start(); onPress?.(); }
  return (<Pressable onPress={doPress}><Animated.View style={[style, { transform: [{ scale }] }]}>{children}</Animated.View></Pressable>);
}


/** =========================
 * Modals
 * ========================= */
function CreateExerciseModal({ visible, onClose, t, onSave }) {
  const [name, setName] = useState(""); const [category, setCategory] = useState("Machine"); const [muscle, setMuscle] = useState("Legs");
  useEffect(() => { if (visible) { setName(""); setCategory("Machine"); setMuscle("Legs"); } }, [visible]);
  function save() { const n = name.trim(); if (!n) return; onSave({ id: `cx_${uid()}`, name: n, category, muscle, source: "custom" }); onClose(); }
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}><View style={styles.modalHeader}><Text style={styles.modalTitle}>{t.library.addCustom}</Text><PillButton label={t.today.close} onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag"><GlassCard title={t.library.name}><TextInput value={name} onChangeText={setName} placeholder="z.B. Hack Squat" placeholderTextColor="#8B8B93" style={styles.input} /></GlassCard><GlassCard title={t.library.category}><View style={styles.rowWrap}>{CATEGORIES.filter((x) => x !== "All").map((x) => <Chip key={x} label={x} active={category === x} onPress={() => setCategory(x)} />)}</View></GlassCard><GlassCard title={t.library.muscle}><View style={styles.rowWrap}>{MUSCLES.filter((x) => x !== "All").map((x) => <Chip key={x} label={x} active={muscle === x} onPress={() => setMuscle(x)} />)}</View></GlassCard><View style={styles.rowWrap}><PillButton label={t.library.save} onPress={save} variant="primary" /></View></ScrollView></KeyboardAvoidingView></SafeAreaView></Modal>);
}

function ImportExercisesModal({ visible, onClose, t, onImport }) {
  const [text, setText] = useState(""); const [msg, setMsg] = useState("");
  useEffect(() => { if (visible) { setText(""); setMsg(""); } }, [visible]);
  function doImport() { const parsed = safeJsonParse(text); if (!parsed.ok) { setMsg(`${t.common.error}: ${parsed.error}`); return; } const v = parsed.value; const arr = Array.isArray(v) ? v : Array.isArray(v?.exercises) ? v.exercises : null; if (!arr) { setMsg(`${t.common.error}: JSON muss ein Array sein`); return; } const cleaned = []; for (const raw of arr) { const name = String(raw?.name || "").trim(); if (!name) continue; cleaned.push({ id: raw?.id ? String(raw.id) : `ix_${uid()}`, name, category: String(raw?.category || "Other").trim(), muscle: String(raw?.muscle || "Other").trim(), source: "import" }); } if (cleaned.length === 0) { setMsg(`${t.common.error}: Keine gültigen Übungen`); return; } const result = onImport(cleaned); setMsg(`${t.common.success}: ${result.added} importiert, ${result.skipped} übersprungen`); }
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}><View style={styles.modalHeader}><Text style={styles.modalTitle}>{t.library.importExercises}</Text><PillButton label={t.today.close} onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag"><GlassCard title="JSON"><Text style={styles.help}>Format: [{"{"}"name":"Hack Squat","category":"Machine","muscle":"Legs"{"}"}]</Text><TextInput value={text} onChangeText={setText} placeholder={t.common.pasteHere} placeholderTextColor="#8B8B93" style={[styles.input, { minHeight: 180 }]} multiline autoCapitalize="none" /><View style={styles.rowWrap}><PillButton label="Importieren" onPress={doImport} variant="primary" /></View>{msg ? <Text style={styles.help}>{msg}</Text> : null}</GlassCard></ScrollView></KeyboardAvoidingView></SafeAreaView></Modal>);
}

function ExportDataModal({ visible, onClose, t, data }) {
  const [text, setText] = useState("");
  useEffect(() => { if (visible) setText(JSON.stringify(data, null, 2)); }, [visible, data]);
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>{t.library.exportData}</Text><PillButton label={t.today.close} onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title="Export JSON"><Text style={styles.help}>Markieren > Kopieren > an Freunde schicken.</Text><TextInput value={text} editable={false} style={[styles.input, { minHeight: 260 }]} multiline /></GlassCard></ScrollView></SafeAreaView></Modal>);
}

function ImportDataModal({ visible, onClose, t, onImport }) {
  const [text, setText] = useState(""); const [msg, setMsg] = useState("");
  useEffect(() => { if (visible) { setText(""); setMsg(""); } }, [visible]);
  function doImport() { const parsed = safeJsonParse(text); if (!parsed.ok) { setMsg(`${t.common.error}: ${parsed.error}`); return; } const result = onImport(parsed.value); if (!result.ok) setMsg(`${t.common.error}: ${result.error}`); else setMsg(`${t.common.success}: Importiert.`); }
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}><View style={styles.modalHeader}><Text style={styles.modalTitle}>{t.library.importData}</Text><PillButton label={t.today.close} onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag"><GlassCard title="Import JSON"><TextInput value={text} onChangeText={setText} placeholder={t.common.pasteHere} placeholderTextColor="#8B8B93" style={[styles.input, { minHeight: 240 }]} multiline autoCapitalize="none" /><View style={styles.rowWrap}><PillButton label="Importieren" onPress={doImport} variant="primary" /></View>{msg ? <Text style={styles.help}>{msg}</Text> : null}</GlassCard></ScrollView></KeyboardAvoidingView></SafeAreaView></Modal>);
}

function NoteModal({ visible, onClose, title, value, onSave }) {
  const [text, setText] = useState("");
  useEffect(() => { if (visible) setText(value || ""); }, [visible, value]);
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>{title || "Note"}</Text><PillButton label="Close" onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title="Note"><TextInput value={text} onChangeText={setText} multiline style={[styles.input, { minHeight: 140 }]} placeholder="Write note..." placeholderTextColor="#8B8B93" /><View style={styles.rowWrap}><PillButton label="Save" onPress={() => { onSave(text); onClose(); }} variant="primary" /></View></GlassCard></ScrollView></SafeAreaView></Modal>);
}

function EditLogModal({ visible, onClose, log, onSave, onDelete }) {
  const [type, setType] = useState("Gym"); const [note, setNote] = useState("");
  useEffect(() => { if (!visible || !log) return; setType(log.type || "Gym"); setNote(log.note || ""); }, [visible, log]);
  if (!log) return null;
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>Edit Log</Text><PillButton label="Cancel" onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title="Type"><View style={styles.rowWrap}>{["Gym","Run","Bike","Swim","Other"].map((x) => <Chip key={x} label={x} active={type === x} onPress={() => setType(x)} />)}</View></GlassCard><GlassCard title="Note"><GlowTextInput value={note} onChangeText={setNote} multiline style={styles.input} placeholder="Note" placeholderTextColor="#8B8B93" /><View style={styles.rowWrap}><PillButton label="Save" onPress={() => onSave({ ...log, type, note: note.trim() || undefined })} variant="primary" /><PillButton label="Delete" onPress={() => onDelete(log.id)} variant="secondary" /></View></GlassCard></ScrollView></SafeAreaView></Modal>);
}

function EditPlanModal({ visible, onClose, plan, onSave, onDelete, onDuplicate }) {
  const [name, setName] = useState(""); const [rest, setRest] = useState("180"); const [confirmDelete, setConfirmDelete] = useState(false);
  useEffect(() => { if (!visible || !plan) return; setName(plan.name || ""); setRest(String(plan.restDefaultSeconds || 180)); setConfirmDelete(false); }, [visible, plan]);
  if (!plan) return null;
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>Edit Plan</Text><PillButton label="Cancel" onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title="Plan Meta"><Text style={styles.label}>Name</Text><GlowTextInput value={name} onChangeText={setName} style={styles.input} placeholder="Plan Name" placeholderTextColor="#8B8B93" /><Text style={styles.label}>Rest default (sec)</Text><GlowTextInput value={rest} onChangeText={(v) => setRest(v.replace(/[^\d]/g, ""))} keyboardType="number-pad" style={styles.input} /><View style={styles.rowWrap}><PillButton label="Save" onPress={() => onSave({ ...plan, name: name.trim() || plan.name, restDefaultSeconds: Number(rest || 0) || 0 })} variant="primary" /><PillButton label="Duplicate" onPress={() => onDuplicate(plan)} variant="secondary" /></View><View style={styles.rowWrap}>{!confirmDelete ? <PillButton label="Delete Plan" onPress={() => setConfirmDelete(true)} variant="secondary" /> : <PillButton label="Confirm Delete" onPress={() => onDelete(plan.id)} variant="secondary" />}</View></GlassCard></ScrollView></SafeAreaView></Modal>);
}


function WorkoutDetailModal({ visible, onClose, t, session, onSaveSession }) {
  const [editMode, setEditMode] = useState(false);
  const [draft, setDraft] = useState(null);
  useEffect(() => { if (!visible || !session) return; setEditMode(false); setDraft(normalizeGymSession(session)); }, [visible, session]);
  if (!session) return null;
  function updateSet(itemId, setIdx, field, value) { setDraft((prev) => { if (!prev) return prev; const nextItems = (prev.items || []).map((it) => { if (it.itemId !== itemId) return it; const nextPerformed = (it.performed || []).map((s, idx) => (idx === setIdx ? { ...s, [field]: value } : s)); return { ...it, performed: nextPerformed }; }); return { ...prev, items: nextItems }; }); }
  function updateExerciseNote(itemId, value) { setDraft((prev) => { if (!prev) return prev; return { ...prev, items: (prev.items || []).map((it) => (it.itemId === itemId ? { ...it, exerciseNote: value } : it)) }; }); }
  function saveLaterEdits() { if (!draft) return; const nextItems = (draft.items || []).map((it) => ({ ...it, performed: (it.performed || []).map((s) => { const missing = String(s?.kg || "").trim() === "" || String(s?.reps || "").trim() === ""; return { ...s, note: s?.note || "", missing }; }) })); const complete = isSessionComplete(nextItems); onSaveSession({ ...draft, items: nextItems, status: complete ? "complete" : "incomplete" }); setEditMode(false); }
  const data = draft || session;
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>{t.history.title}</Text><PillButton label={t.today.close} onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title={t.history.summary}><Text style={styles.listTitle}>{session.planName}</Text><Text style={styles.listMeta}>{new Date(session.startedAt).toLocaleString()} - {t.history.duration}: ~{session.durationMin} min</Text><Text style={[styles.listMeta, { marginTop: 6 }]}>{t.workout.progress}: {session.doneSets}/{session.totalSets}</Text>{session.status === "incomplete" ? <Text style={styles.incompleteBadge}>Incomplete</Text> : null}<Text style={[styles.listMeta, { marginTop: 6 }]}>Volume: ~{session.totalVolumeKg || 0} kg*reps - Reps: {session.totalReps || 0}</Text></GlassCard>
  {(session.exerciseTrends || []).length ? (<GlassCard title="Trend / PR">{(session.exerciseTrends || []).map((tr) => (<View key={`tr_${tr.exerciseId}`} style={styles.listItem}><Text style={styles.listTitle}>{tr.name}</Text><Text style={styles.listMeta}>Max: {tr.maxKg} kg - Prev: {tr.prevMaxKg} kg - D {tr.deltaKg >= 0 ? "+" : ""}{tr.deltaKg.toFixed(1)} kg</Text></View>))}</GlassCard>) : null}
  <GlassCard title="Übungen">{(data.items || []).map((it) => (<View key={it.itemId} style={styles.planItem}><Text style={styles.listTitle}>{it.name}</Text><Text style={styles.listMeta}>{it.category} - {it.muscle}</Text>{editMode ? (<><Text style={styles.smallLabel}>Exercise Note</Text><TextInput value={it.exerciseNote || ""} onChangeText={(v) => updateExerciseNote(it.itemId, v)} multiline style={styles.input} /></>) : it.exerciseNote ? <Text style={styles.help}>Note: {it.exerciseNote}</Text> : null}<View style={{ marginTop: 10 }}>{it.performed.map((s, idx) => { const line = `${idx + 1}. ${s.kg || "-"} kg x ${s.reps || "-"} reps`; return (<View key={`${it.itemId}-${idx}`} style={[styles.detailSetRow, s.done ? styles.detailSetDone : null, editMode ? { flexDirection: "column", alignItems: "stretch" } : null]}>{!editMode ? (<><Text style={s.done ? styles.detailSetTextDone : styles.detailSetText}>{line}</Text><Text style={s.done ? styles.detailBadgeDone : styles.detailBadge}>{s.done ? t.history.done : ""}</Text></>) : (<><View style={styles.setRow}><View style={{ flex: 1, marginRight: 10 }}><Text style={styles.smallLabel}>kg</Text><TextInput value={String(s.kg || "")} onChangeText={(v) => updateSet(it.itemId, idx, "kg", v.replace(/[^\d.]/g, ""))} keyboardType="decimal-pad" style={styles.inputSmall} /></View><View style={{ flex: 1 }}><Text style={styles.smallLabel}>reps</Text><TextInput value={String(s.reps || "")} onChangeText={(v) => updateSet(it.itemId, idx, "reps", v.replace(/[^\d]/g, ""))} keyboardType="number-pad" style={styles.inputSmall} /></View></View><Text style={styles.smallLabel}>Set Note</Text><TextInput value={s.note || ""} onChangeText={(v) => updateSet(it.itemId, idx, "note", v)} multiline style={styles.input} /></>)}</View>); })}</View></View>))}</GlassCard>
  {session.status === "incomplete" ? (<View style={styles.rowWrap}>{!editMode ? <PillButton label="Complete later" onPress={() => setEditMode(true)} variant="secondary" /> : null}{editMode ? <PillButton label="Save" onPress={saveLaterEdits} variant="primary" /> : null}</View>) : null}
  </ScrollView></SafeAreaView></Modal>);
}

function ExerciseDetailModal({ visible, onClose, exercise, prefs, setPrefs, onSaveExerciseDefaults }) {
  const [howtoOpen, setHowtoOpen] = useState(false); const [defaultsOpen, setDefaultsOpen] = useState(false); const [setupOpen, setSetupOpen] = useState(false);
  const [repMin, setRepMin] = useState(""); const [repMax, setRepMax] = useState(""); const [restSeconds, setRestSeconds] = useState(""); const [startKg, setStartKg] = useState("");
  const [setupSeat, setSetupSeat] = useState(""); const [setupBench, setSetupBench] = useState(""); const [setupBackrest, setSetupBackrest] = useState(""); const [setupPads, setSetupPads] = useState(""); const [setupHandle, setSetupHandle] = useState(""); const [setupPins, setSetupPins] = useState(""); const [setupNotes, setSetupNotes] = useState("");
  useEffect(() => { if (!exercise || !visible) return; const override = prefs?.exerciseDefaultsOverrides?.[exercise.id] || {}; const d = { ...(exercise.defaults || {}), ...override }; const setupOverride = prefs?.exerciseSetupOverrides?.[exercise.id] || {}; const setup = { ...(exercise.setup || {}), ...setupOverride }; setRepMin(String(d?.repRange?.min ?? "")); setRepMax(String(d?.repRange?.max ?? "")); setRestSeconds(String(d?.restSeconds ?? "")); setStartKg(String(d?.startKg ?? "")); setSetupSeat(String(setup?.seat ?? "")); setSetupBench(String(setup?.bench ?? "")); setSetupBackrest(String(setup?.backrest ?? "")); setSetupPads(String(setup?.pads ?? "")); setSetupHandle(String(setup?.handle ?? "")); setSetupPins(String(setup?.pins ?? "")); setSetupNotes(String(setup?.notes ?? "")); }, [exercise, visible]);
  if (!exercise) return null;
  const howto = exercise.howto || {};
  function saveDefaults() { onSaveExerciseDefaults(exercise, { repRange: { min: Number(repMin || 0) || undefined, max: Number(repMax || 0) || undefined }, restSeconds: Number(restSeconds || 0) || undefined, startKg: Number(String(startKg || "").replace(",", ".")) || undefined }); }
  function saveSetup() { onSaveExerciseDefaults(exercise, undefined, { seat: setupSeat.trim() || undefined, bench: setupBench.trim() || undefined, backrest: setupBackrest.trim() || undefined, pads: setupPads.trim() || undefined, handle: setupHandle.trim() || undefined, pins: setupPins.trim() || undefined, notes: setupNotes.trim() || undefined }); }
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>Exercise Detail</Text><PillButton label="Close" onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}>
    <GlassCard title={exercise.name}><Text style={styles.listMeta}>{exercise.category} - {exercise.muscle}</Text></GlassCard>
    <GlassCard title="How-To"><Pressable onPress={() => setHowtoOpen((v) => !v)} style={styles.accordionBtn}><Text style={styles.listTitle}>{howtoOpen ? "Hide" : "Show"} How-To</Text></Pressable>{howtoOpen ? (<View style={{ marginTop: 10 }}>{howto.setup ? <Text style={styles.help}>Setup: {howto.setup}</Text> : <Text style={styles.help}>No setup yet.</Text>}{Array.isArray(howto.cues) ? howto.cues.slice(0, 5).map((x, i) => <Text key={`c_${i}`} style={styles.help}>- Cue: {x}</Text>) : null}{Array.isArray(howto.mistakes) ? howto.mistakes.slice(0, 5).map((x, i) => <Text key={`m_${i}`} style={styles.help}>- Mistake: {x}</Text>) : null}</View>) : null}</GlassCard>
    <GlassCard title="Defaults"><Pressable onPress={() => setDefaultsOpen((v) => !v)} style={styles.accordionBtn}><Text style={styles.listTitle}>{defaultsOpen ? "Hide" : "Show"} Defaults</Text></Pressable>{defaultsOpen ? (<View><View style={styles.setRow}><View style={{ flex: 1, marginRight: 10 }}><Text style={styles.smallLabel}>Rep min</Text><TextInput value={repMin} onChangeText={(v) => setRepMin(v.replace(/[^\d]/g, ""))} keyboardType="number-pad" style={styles.inputSmall} /></View><View style={{ flex: 1 }}><Text style={styles.smallLabel}>Rep max</Text><TextInput value={repMax} onChangeText={(v) => setRepMax(v.replace(/[^\d]/g, ""))} keyboardType="number-pad" style={styles.inputSmall} /></View></View><View style={styles.setRow}><View style={{ flex: 1, marginRight: 10 }}><Text style={styles.smallLabel}>Rest (sec)</Text><TextInput value={restSeconds} onChangeText={(v) => setRestSeconds(v.replace(/[^\d]/g, ""))} keyboardType="number-pad" style={styles.inputSmall} /></View><View style={{ flex: 1 }}><Text style={styles.smallLabel}>Start kg</Text><TextInput value={startKg} onChangeText={(v) => setStartKg(v.replace(/[^\d.]/g, ""))} keyboardType="decimal-pad" style={styles.inputSmall} /></View></View><View style={styles.rowWrap}><PillButton label="Save defaults" onPress={saveDefaults} variant="primary" /></View></View>) : null}</GlassCard>
    <GlassCard title="Setup (Machine/Bench)"><Pressable onPress={() => setSetupOpen((v) => !v)} style={styles.accordionBtn}><Text style={styles.listTitle}>{setupOpen ? "Hide" : "Show"} Setup</Text></Pressable>{setupOpen ? (<View><Text style={styles.smallLabel}>Seat</Text><GlowTextInput value={setupSeat} onChangeText={setSetupSeat} style={styles.input} placeholder="e.g. 5" placeholderTextColor="#8B8B93" /><Text style={styles.smallLabel}>Bench</Text><GlowTextInput value={setupBench} onChangeText={setSetupBench} style={styles.input} placeholder="e.g. incline 30deg" placeholderTextColor="#8B8B93" /><Text style={styles.smallLabel}>Backrest</Text><GlowTextInput value={setupBackrest} onChangeText={setSetupBackrest} style={styles.input} placeholder="position" placeholderTextColor="#8B8B93" /><Text style={styles.smallLabel}>Pads</Text><GlowTextInput value={setupPads} onChangeText={setSetupPads} style={styles.input} placeholder="pad position" placeholderTextColor="#8B8B93" /><Text style={styles.smallLabel}>Handle</Text><GlowTextInput value={setupHandle} onChangeText={setSetupHandle} style={styles.input} placeholder="grip/handle" placeholderTextColor="#8B8B93" /><Text style={styles.smallLabel}>Pins</Text><GlowTextInput value={setupPins} onChangeText={setSetupPins} style={styles.input} placeholder="stack pin" placeholderTextColor="#8B8B93" /><Text style={styles.smallLabel}>Notes</Text><GlowTextInput value={setupNotes} onChangeText={setSetupNotes} multiline style={styles.input} placeholder="extra setup notes" placeholderTextColor="#8B8B93" /><View style={styles.rowWrap}><PillButton label="Save setup" onPress={saveSetup} variant="primary" /></View></View>) : null}</GlassCard>
  </ScrollView></SafeAreaView></Modal>);
}

function GroupModal({ visible, onClose, t, user, myGroups, activeGroupId, setActiveGroupId, sharedPlans, onRefreshSharedPlans, onCreateGroup, onJoinByCode, onLeaveGroup, onImportSharedPlan, members, onRefreshMembers, onUpdateMemberRole, onRemoveMember, onRegenerateCode }) {
  const [groupName, setGroupName] = useState(""); const [joinCode, setJoinCode] = useState("");
  useEffect(() => { if (!visible) return; setGroupName(""); setJoinCode(""); }, [visible]);
  const activeGroup = myGroups.find((g) => g.id === activeGroupId) || null;
  const myRole = activeGroup?.role || "member";
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>Groups</Text><PillButton label={t.today.close} onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
    <GlassCard title="Create group"><TextInput value={groupName} onChangeText={setGroupName} placeholder="e.g. Team Gym" placeholderTextColor="#8B8B93" style={styles.input} /><View style={styles.rowWrap}><PillButton label="Create" onPress={() => onCreateGroup(groupName)} variant="primary" /></View></GlassCard>
    <GlassCard title="Join group (code)"><TextInput value={joinCode} onChangeText={(v) => setJoinCode(v.toUpperCase().trim())} placeholder="8-char code" placeholderTextColor="#8B8B93" style={styles.input} autoCapitalize="characters" autoCorrect={false} /><View style={styles.rowWrap}><PillButton label="Join" onPress={() => onJoinByCode(joinCode)} variant="primary" /></View></GlassCard>
    <GlassCard title="My groups">{!supabase ? <Text style={styles.muted}>Supabase not configured.</Text> : !user ? <Text style={styles.muted}>Login required.</Text> : myGroups.length === 0 ? <Text style={styles.muted}>No groups yet.</Text> : myGroups.map((g) => (<View key={g.id} style={styles.listItemRow}><View style={{ flex: 1 }}><Text style={styles.listTitle}>{g.name}</Text><Text style={styles.listMeta}>Code: {g.code} - Role: {g.role} {activeGroupId === g.id ? "- ACTIVE" : ""}</Text></View><PillButton label="Select" onPress={() => { setActiveGroupId(g.id); onRefreshSharedPlans(g.id); }} variant="secondary" /><PillButton label="Leave" onPress={() => onLeaveGroup(g.id)} variant="secondary" /></View>))}{activeGroup && myRole === "owner" ? <View style={styles.rowWrap}><PillButton label="Regenerate Code" onPress={onRegenerateCode} variant="secondary" /></View> : null}</GlassCard>
    <GlassCard title="Members">{!activeGroup ? <Text style={styles.muted}>Select a group first.</Text> : (<><View style={styles.rowWrap}><PillButton label="Refresh Members" onPress={() => onRefreshMembers(activeGroup.id)} variant="secondary" /></View>{(members || []).length === 0 ? <Text style={styles.muted}>No members found.</Text> : (members || []).map((m) => (<View key={m.user_id} style={styles.listItemRow}><View style={{ flex: 1 }}><Text style={styles.listTitle}>{m.user_id}</Text><Text style={styles.listMeta}>Role: {m.role}</Text></View>{(myRole === "owner" || myRole === "admin") && m.role !== "owner" ? (<><PillButton label="Admin" onPress={() => onUpdateMemberRole(m.user_id, "admin")} variant="secondary" /><PillButton label="Kick" onPress={() => onRemoveMember(m.user_id)} variant="secondary" /></>) : null}</View>))}</>)}</GlassCard>
  </ScrollView></SafeAreaView></Modal>);
}


/** =========================
 * Screens
 * ========================= */
function TodayScreen({ t, note, setNote, logs, addLog, sessions, onOpenSession, todayAgenda, onDoneAgenda, onStartAgendaGym, onStartAgendaEndurance, onMoveAgendaTomorrow, onCopyAgendaNextWeek, onOpenLog }) {
  const [showLog, setShowLog] = useState(false);
  return (<ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag"><Text style={styles.h1}>{t.today.title}</Text>
    {todayAgenda.length === 0 ? <GlassCard><Text style={styles.muted}>Kein Training geplant. Nutze den Planer um deine Woche zu fuellen.</Text></GlassCard> : todayAgenda.map((e) => (<View key={e.id} style={[styles.agendaCard, e.status === "done" ? styles.agendaDone : null]}><Text style={styles.agendaTitle}>{e.title}</Text><Text style={styles.agendaMeta}>{e.startTime} - {e.durationMin} min - {e.sportType}</Text>{e.status === "done" ? <Text style={styles.agendaStatus}>Erledigt</Text> : <View style={styles.rowWrap}>{e.sportType === "Gym" && e.planId ? <Pressable onPress={() => onStartAgendaGym(e)} style={styles.softButton}><Text style={styles.softButtonText}>Workout starten</Text></Pressable> : ["Run","Bike","Swim"].includes(e.sportType) ? <Pressable onPress={() => onStartAgendaEndurance(e)} style={styles.softButton}><Text style={styles.softButtonText}>Start</Text></Pressable> : <PillButton label="Done" onPress={() => onDoneAgenda(e)} variant="secondary" />}</View>}</View>))}
    {sessions.length > 0 ? <View style={{marginTop: 20}}><Text style={styles.cardTitle}>Letzte Workouts</Text>{sessions.slice(0, 3).map(function(s) { return (<Pressable key={s.id} style={styles.listItem} onPress={() => onOpenSession(s)}><Text style={styles.listTitle}>{s.planName}</Text><Text style={styles.listMeta}>{new Date(s.startedAt).toLocaleDateString()} - {s.doneSets}/{s.totalSets} Sets</Text></Pressable>); })}</View> : null}
    <Pressable onPress={function(){setShowLog(!showLog)}} style={{marginTop: 24}}><Text style={styles.cardTitle}>{showLog ? "Schnell-Log ausblenden" : "Schnell-Log"}</Text></Pressable>
    {showLog ? <View style={{marginTop: 8}}><GlowTextInput value={note} onChangeText={setNote} placeholder='z.B. "Zone 2 45min"' placeholderTextColor="#8B8B93" style={styles.input} /><View style={styles.rowWrap}>{["Gym","Run","Bike","Swim"].map(function(x){return <PillButton key={x} label={"+ "+x} onPress={function(){addLog(x)}} variant="secondary" />})}</View>{logs.slice(0, 5).map(function(l) { return (<Pressable key={l.id} style={styles.listItem} onPress={() => onOpenLog(l)}><Text style={styles.listTitle}>{l.type}</Text><Text style={styles.listMeta}>{new Date(l.createdAt).toLocaleString()}{l.note ? " - " + l.note : ""}</Text></Pressable>); })}</View> : null}
  </ScrollView>);
}

function LibraryPickerList({ t, allExercises, onPick }) {
  const [q, setQ] = useState(""); const [cat, setCat] = useState("All"); const [mus, setMus] = useState("All");
  const debouncedQ = useDebouncedValue(q, 250);
  const filtered = useMemo(() => smartSearch(allExercises, debouncedQ, cat, mus, 120), [allExercises, debouncedQ, cat, mus]);
  return (<ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
    <GlassCard title={t.library.search}><GlowTextInput value={q} onChangeText={setQ} placeholder={t.library.search} placeholderTextColor="#8B8B93" style={styles.input} autoCapitalize="none" autoCorrect={false} /><Text style={styles.label}>{t.library.filters.category}</Text><View style={styles.rowWrap}>{CATEGORIES.map((x) => <Chip key={x} label={x} active={cat === x} onPress={() => setCat(x)} />)}</View><Text style={styles.label}>{t.library.filters.muscle}</Text><View style={styles.rowWrap}>{MUSCLES.map((x) => <Chip key={x} label={x} active={mus === x} onPress={() => setMus(x)} />)}</View></GlassCard>
    <GlassCard title="Ergebnisse">{filtered.length === 0 ? <ListEmpty text={t.library.noResults} /> : filtered.map(function(e) { return (<View key={e.id} style={styles.listItemRow}><View style={{ flex: 1 }}><Text style={styles.listTitle}>{e.name}{e.source && e.source !== "base" ? <Text style={styles.badge}> - {e.source}</Text> : null}</Text><Text style={styles.listMeta}>{e.category} - {e.muscle}</Text></View><RowButton label={t.library.addToPlan} onPress={() => onPick(e)} variant="secondary" /></View>); })}</GlassCard>
  </ScrollView>);
}

function PlansScreen({ t, plans, setPlans, activePlanId, setActivePlanId, onStartWorkout, allExercises, activeGroup, onOpenGroups, onSharePlan, sharedPlans, onOpenSharedLive, onImportSharedPlan, myRole, sharedPlanOpen, onCloseSharedPlan, onSaveSharedPlan, sharedPlanSaving, remoteUpdateFlag, onReloadSharedPlan }) {
  const [newPlanName, setNewPlanName] = useState(""); const [editPlanOpen, setEditPlanOpen] = useState(false);
  const [collapsedSections, setCollapsedSections] = useState({});
  const [expandedItem, setExpandedItem] = useState(null);
  const activePlan = useMemo(() => plans.find((p) => p.id === activePlanId) || null, [plans, activePlanId]);
  function createPlan() { const name = newPlanName.trim(); if (!name) return; const p = { id: uid(), name, restDefaultSeconds: 180, items: [] }; setPlans((prev) => [p, ...prev]); setNewPlanName(""); }
  function updatePlan(planId, patch) { setPlans((prev) => prev.map((p) => (p.id === planId ? { ...p, ...patch } : p))); }
  function savePlanMeta(nextPlan) { setPlans((prev) => prev.map((p) => (p.id === nextPlan.id ? { ...p, name: nextPlan.name, restDefaultSeconds: nextPlan.restDefaultSeconds } : p))); setEditPlanOpen(false); }
  function deletePlan(planId) { setPlans((prev) => prev.filter((p) => p.id !== planId)); setEditPlanOpen(false); setActivePlanId(null); }
  function duplicatePlan(plan) { const copy = { ...plan, id: uid(), name: `${plan.name} (Copy)`, items: (plan.items || []).map((it) => ({ ...it, id: uid(), sets: (it.sets || []).map((s) => ({ ...s })) })) }; setPlans((prev) => [copy, ...prev]); }
  function addExerciseToPlan(plan, exercise) { const already = plan.items.some((it) => it.exerciseId === exercise.id); if (already) return; const newItem = { id: uid(), exerciseId: exercise.id, progressionMode: "double", loadRule: "range_then_load", incrementKg: getIncrementByCategory(exercise.category), fixedReps: "5", backoffPercent: "12", deloadEnabled: false, sets: [{ targetKg: "", targetReps: "", targetRepMin: "6", targetRepMax: "10", targetRir: "2" }] }; updatePlan(plan.id, { items: [...plan.items, newItem] }); }
  function addSetToItem(plan, itemId) { const items = plan.items.map((it) => it.id === itemId ? { ...it, sets: [...it.sets, { targetKg: "", targetReps: "", targetRepMin: "6", targetRepMax: "10", targetRir: "2" }] } : it); updatePlan(plan.id, { items }); }
  function removeSetFromItem(plan, itemId, setIdx) { const items = plan.items.map((it) => { if (it.id !== itemId) return it; if (it.sets.length <= 1) return it; return { ...it, sets: it.sets.filter(function(_, i) { return i !== setIdx; }) }; }); updatePlan(plan.id, { items }); }
  function removePlanItem(plan, itemId) { updatePlan(plan.id, { items: plan.items.filter((it) => it.id !== itemId) }); }
  function updateTarget(plan, itemId, setIdx, field, value) { const items = plan.items.map((it) => { if (it.id !== itemId) return it; const sets = it.sets.map((s, idx) => (idx === setIdx ? { ...s, [field]: value } : s)); return { ...it, sets }; }); updatePlan(plan.id, { items }); }
  function updateItemField(plan, itemId, field, value) { const items = plan.items.map((it) => (it.id === itemId ? { ...it, [field]: value } : it)); updatePlan(plan.id, { items }); }
  const [libraryOpen, setLibraryOpen] = useState(false);

  if (sharedPlanOpen) {
    const readOnly = !(myRole === "owner" || myRole === "admin");
    const sp = sharedPlanOpen.plan || { name: sharedPlanOpen.plan_name || "Shared Plan", restDefaultSeconds: 180, items: [] };
    return (<ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag"><View style={styles.rowBetween}><Text style={styles.h1}>LIVE - {sp.name}</Text><PillButton label={t.plans.back} onPress={onCloseSharedPlan} variant="secondary" /></View><GlassCard title="Shared Plan"><Text style={styles.listMeta}>Role: {myRole || "member"} - {sharedPlanSaving ? "Saving..." : "Saved"}</Text>{remoteUpdateFlag ? <View style={styles.rowWrap}><Text style={styles.help}>Updated remotely.</Text><PillButton label="Reload" onPress={onReloadSharedPlan} variant="secondary" /></View> : null}<Text style={styles.label}>Name</Text><TextInput value={String(sp.name || "")} editable={!readOnly} onChangeText={(v) => onSaveSharedPlan({ ...sp, name: v })} style={styles.input} placeholderTextColor="#8B8B93" /></GlassCard></ScrollView>);
  }

  if (!activePlan) {
    return (<ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag"><Text style={styles.h1}>{t.plans.title}</Text>
      {supabase ? <GlassCard title="Group"><Text style={styles.listMeta}>{activeGroup ? `Active: ${activeGroup.name} (Code: ${activeGroup.code})` : "No group selected."}</Text><View style={styles.rowWrap}><PillButton label="Manage Groups" onPress={onOpenGroups} variant="secondary" /></View></GlassCard> : null}
      <GlassCard><View style={styles.setRow}><View style={{ flex: 1, marginRight: 10 }}><GlowTextInput value={newPlanName} onChangeText={setNewPlanName} placeholder={t.plans.namePlaceholder} placeholderTextColor="#8B8B93" style={styles.input} /></View><PillButton label="+" onPress={createPlan} variant="primary" /></View></GlassCard>
      {sharedPlans.length > 0 ? <GlassCard title="Shared Plans">{sharedPlans.map((sp) => (<View key={sp.id} style={styles.listItemRow}><View style={{ flex: 1 }}><Text style={styles.listTitle}>{sp.plan_name}</Text></View><PillButton label="Open" onPress={() => onOpenSharedLive(sp)} variant="secondary" /><PillButton label="Import" onPress={() => onImportSharedPlan(sp)} variant="secondary" /></View>))}</GlassCard> : null}
      <GlassCard title="Deine Plaene">{plans.length === 0 ? <ListEmpty text="No plans yet." /> : plans.map(function(p) { return (<Pressable key={p.id} style={styles.listItem} onPress={() => setActivePlanId(p.id)}><Text style={styles.listTitle}>{p.name}</Text><Text style={styles.listMeta}>{p.items.length} Übungen - Pause: {p.restDefaultSeconds}s</Text></Pressable>); })}</GlassCard>
    </ScrollView>);
  }

  const itemsWithExercise = activePlan.items.map((it) => ({ ...it, exercise: allExercises.find((e) => e.id === it.exerciseId) || null }));
  function summaryText(it) { var s = it.sets || []; if (s.length === 0) return ""; var rm = s[0]?.targetRepMin || "?"; var rx = s[0]?.targetRepMax || "?"; return s.length + "x" + rm + "-" + rx; }
  return (<ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
    <Pressable onPress={() => setActivePlanId(null)} style={styles.backRow}><Text style={styles.backText}>Alle Plaene</Text></Pressable>
    <Pressable onPress={() => setEditPlanOpen(true)}><Text style={styles.h1}>{activePlan.name}</Text></Pressable>
    <Pressable onPress={() => onStartWorkout(activePlan)} style={styles.bigButton}><Text style={styles.bigButtonText}>Workout starten</Text></Pressable>
    {(function() { var lastSection = ""; return itemsWithExercise.map(function(it) { var showSection = it.section && it.section !== lastSection; var sec = it.section || lastSection; lastSection = sec; var isSecCollapsed = collapsedSections[sec]; var isExpanded = expandedItem === it.id; return (<React.Fragment key={it.id}>{showSection ? <Pressable onPress={function(){setCollapsedSections(function(prev){var n={};for(var k in prev)n[k]=prev[k];n[sec]=!prev[sec];return n;});}} style={styles.sectionDivider}><View style={styles.sectionLine} /><Text style={styles.sectionLabel}>{sec} {isSecCollapsed ? "+" : "-"}</Text><View style={styles.sectionLine} /></Pressable> : null}
    {!isSecCollapsed ? <Pressable onPress={function(){setExpandedItem(isExpanded ? null : it.id);}} style={[styles.planItemCompact, isExpanded ? styles.planItemExpanded : null]}>
      <View style={styles.rowBetween}><Text style={styles.listTitle}>{it.exercise ? it.exercise.name : "Exercise"}</Text><Text style={styles.compactMeta}>{summaryText(it)}</Text></View>
      {isExpanded ? <View style={{ marginTop: 12 }}>
        <View style={styles.rowBetween}><Text style={styles.smallLabel}>Progression</Text><View style={styles.rowWrap}>{[{k:"double",l:"Double"},{k:"top_backoff",l:"Top+Backoff"},{k:"fixed_load",l:"Fixed"}].map(function(m){return <Chip key={m.k} label={m.l} active={(it.progressionMode||"double")===m.k} onPress={function(){updateItemField(activePlan,it.id,"progressionMode",m.k)}} />})}</View></View>
        <View style={styles.setRow}><View style={{flex:1,marginRight:8}}><Text style={styles.smallLabel}>Inkrement kg</Text><TextInput value={String(it.incrementKg??"")} onChangeText={function(v){updateItemField(activePlan,it.id,"incrementKg",v.replace(",","."))}} keyboardType="decimal-pad" style={styles.inputSmall} /></View><View style={{flex:1}}><Text style={styles.smallLabel}>{it.progressionMode==="top_backoff"?"Backoff %":"Fixed reps"}</Text><TextInput value={String((it.progressionMode==="top_backoff"?it.backoffPercent:it.fixedReps)||"")} onChangeText={function(v){updateItemField(activePlan,it.id,it.progressionMode==="top_backoff"?"backoffPercent":"fixedReps",v.replace(/[^\d.]/g,""))}} keyboardType="decimal-pad" style={styles.inputSmall} /></View></View>
        {it.sets.map(function(s,idx){return (<View key={it.id+"-t-"+idx} style={styles.planSetBlock}><View style={styles.rowBetween}><Text style={styles.smallLabel}>Set {idx+1}</Text>{it.sets.length>1?<Pressable onPress={function(){removeSetFromItem(activePlan,it.id,idx)}} hitSlop={8}><Text style={{color:"#9A2C2C",fontSize:12,fontWeight:"700"}}>x</Text></Pressable>:null}</View><View style={styles.setRow}><View style={{flex:1,marginRight:6}}><Text style={styles.smallLabel}>kg</Text><TextInput value={String(s.targetKg||"")} onChangeText={function(v){updateTarget(activePlan,it.id,idx,"targetKg",v.replace(",","."))}} keyboardType="decimal-pad" style={styles.inputSmall} /></View><View style={{flex:1,marginRight:6}}><Text style={styles.smallLabel}>min</Text><TextInput value={String(s.targetRepMin||s.targetReps||"")} onChangeText={function(v){updateTarget(activePlan,it.id,idx,"targetRepMin",v.replace(/[^\d]/g,""))}} keyboardType="number-pad" style={styles.inputSmall} /></View><View style={{flex:1,marginRight:6}}><Text style={styles.smallLabel}>max</Text><TextInput value={String(s.targetRepMax||s.targetReps||"")} onChangeText={function(v){updateTarget(activePlan,it.id,idx,"targetRepMax",v.replace(/[^\d]/g,""))}} keyboardType="number-pad" style={styles.inputSmall} /></View><View style={{flex:1}}><Text style={styles.smallLabel}>RIR</Text><TextInput value={String(s.targetRir||"")} onChangeText={function(v){updateTarget(activePlan,it.id,idx,"targetRir",v.replace(/[^\d]/g,""))}} keyboardType="number-pad" style={styles.inputSmall} /></View></View></View>)})}
        <View style={[styles.rowWrap,{justifyContent:"space-between"}]}><PillButton label="+ Set" onPress={function(){addSetToItem(activePlan,it.id)}} variant="secondary" /><PillButton label="Entfernen" onPress={function(){removePlanItem(activePlan,it.id)}} variant="secondary" /></View>
      </View> : null}
    </Pressable> : null}</React.Fragment>); }); })()}
    <View style={[styles.rowWrap,{marginTop:20}]}><PillButton label={t.plans.addExercise} onPress={() => setLibraryOpen(true)} variant="secondary" /></View>
    <Modal visible={libraryOpen} animationType="slide" onRequestClose={() => setLibraryOpen(false)}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>{t.library.title}</Text><PillButton label={t.library.close} onPress={() => setLibraryOpen(false)} variant="secondary" /></View><LibraryPickerList t={t} allExercises={allExercises} onPick={(ex) => { addExerciseToPlan(activePlan, ex); setLibraryOpen(false); }} /></SafeAreaView></Modal>
    <EditPlanModal visible={editPlanOpen} onClose={() => setEditPlanOpen(false)} plan={activePlan} onSave={savePlanMeta} onDelete={deletePlan} onDuplicate={duplicatePlan} />
  </ScrollView>);
}


function WorkoutScreen({ t, plan, workout, setWorkout, onFinish, allExercises, onOpenExerciseDetail, sessions }) {
  const [expandedEx, setExpandedEx] = useState(null);
  const [howtoEx, setHowtoEx] = useState(null);
  const [timerTick, setTimerTick] = useState(0);
  // Timestamp-based timer - survives background
  useEffect(() => { var iv = setInterval(function(){ setTimerTick(function(t){return t+1}); }, 500); return function(){ clearInterval(iv); }; }, []);
  var restRemaining = 0;
  if (workout.restStartedAt && workout.restDurationSec) { restRemaining = Math.max(0, workout.restDurationSec - Math.floor((Date.now() - workout.restStartedAt) / 1000)); }
  if (restRemaining <= 0 && workout.restStartedAt) { /* auto-clear but don't mutate in render */ }
  function startRest(sec) { setWorkout(function(prev){ return { ...prev, restStartedAt: Date.now(), restDurationSec: sec }; }); }
  function clearRest() { setWorkout(function(prev){ return { ...prev, restStartedAt: null, restDurationSec: 0 }; }); }

  var items = useMemo(function(){ return plan.items.map(function(it){ return { ...it, exercise: allExercises.find(function(e){return e.id===it.exerciseId}) || { name: "Exercise", category: "", muscle: "", inputType: "kg_reps", howto: [] } }; }); }, [plan, allExercises]);
  var totals = useMemo(function(){ var ts=0,ds=0; items.forEach(function(it){ var sets = workout.sets[it.id]||[]; ts+=sets.length; ds+=sets.filter(function(s){return s.done}).length; }); return {totalSets:ts,doneSets:ds}; }, [items, workout]);

  // PR history lookup
  var prMap = useMemo(function(){ var m = {}; (sessions||[]).forEach(function(sess){ (sess.items||[]).forEach(function(it){ (it.performed||[]).forEach(function(s){ if(!s.done) return; var kg=toNum(s.kg); if(kg<=0) return; if(!m[it.exerciseId]||kg>m[it.exerciseId]) m[it.exerciseId]=kg; }); }); }); return m; }, [sessions]);

  // Find first non-complete exercise
  var activeItemId = null;
  for(var i=0;i<items.length;i++){ var ss=workout.sets[items[i].id]||[]; if(!ss.every(function(s){return s.done})){ activeItemId=items[i].id; break; } }
  // Auto-expand active
  useEffect(function(){ if(activeItemId) setExpandedEx(activeItemId); }, [activeItemId]);

  function updateWorkoutSet(itemId, setIdx, field, value) { setWorkout(function(prev){ var current = prev.sets[itemId]||[]; var nextArr = current.map(function(s,idx){return idx===setIdx?{...s,[field]:value}:s}); return { ...prev, sets: { ...prev.sets, [itemId]: nextArr } }; }); }

  function toggleDone(itemId, setIdx) {
    var wasDone = (workout.sets[itemId]||[])[setIdx]?.done;
    setWorkout(function(prev){ var current = prev.sets[itemId]||[]; var nextArr = current.map(function(s,idx){return idx===setIdx?{...s,done:!s.done}:s}); var item = items.find(function(x){return x.id===itemId})||{};
      // PR check
      var prMsg = "";
      if(!wasDone){ var kg=toNum(nextArr[setIdx]?.kg); var prevBest=prMap[item.exerciseId]||0; if(kg>0 && kg>prevBest) prMsg = "NEUES MAX: "+kg+" kg!"; }
      var tip = evaluateSetSuggestion(item, nextArr[setIdx], nextArr, setIdx);
      var nextSuggestions = { ...(prev.suggestions||{}), [itemId+"_"+setIdx]: !wasDone ? (prMsg || tip) : "" };
      if (!wasDone && item?.progressionMode === "top_backoff" && setIdx === 0) { var topKg = toNum(nextArr[0]?.kg); var backoffPct = toNum(item.backoffPercent || 12) || 12; var backoffKg = topKg > 0 ? (topKg * (1 - backoffPct / 100)).toFixed(1) : ""; for (var j = 1; j < nextArr.length; j++) { if (!nextArr[j].kg) nextArr[j] = { ...nextArr[j], kg: backoffKg }; } }
      return { ...prev, sets: { ...prev.sets, [itemId]: nextArr }, suggestions: nextSuggestions }; });
    if (!wasDone) startRest(plan.restDefaultSeconds || 180);
  }

  function renderSetInput(it, s, idx) {
    var inputType = it.exercise?.inputType || "kg_reps";
    if (inputType === "check") {
      return (<Pressable key={it.id+"-w-"+idx} onPress={function(){toggleDone(it.id,idx)}} style={s.done ? styles.doneSetRow : styles.checkRow}><Text style={s.done ? styles.doneSetText : styles.listTitle}>{s.done ? "Erledigt" : "Antippen wenn fertig"}</Text>{s.done ? <Text style={styles.doneSetUndo}>Undo</Text> : null}</Pressable>);
    }
    if (s.done) {
      var label = "";
      if (inputType === "kg_reps") label = (s.kg||"-")+" kg x "+(s.reps||"-");
      else if (inputType === "kg_dist") label = (s.kg||"-")+" kg - "+(s.dist||"-")+" m";
      else if (inputType === "reps") label = (s.reps||"-")+" reps";
      else if (inputType === "duration") label = (s.duration||"-")+" min";
      else if (inputType === "time_sec") label = (s.duration||"-")+" sek";
      else if (inputType === "dist") label = (s.dist||"-")+" m";
      else label = (s.kg||"-")+" kg x "+(s.reps||"-");
      return (<Pressable key={it.id+"-w-"+idx} onPress={function(){toggleDone(it.id,idx)}} style={styles.doneSetRow}><Text style={styles.doneSetText}>{label}</Text><Text style={styles.doneSetUndo}>Undo</Text></Pressable>);
    }
    return (<View key={it.id+"-w-"+idx} style={styles.workoutSetRow}>
      <Text style={styles.setNumLabel}>{idx+1}</Text>
      {(inputType === "kg_reps" || inputType === "kg_dist") ? <View style={{flex:1,marginRight:8}}><TextInput value={s.kg} onChangeText={function(v){updateWorkoutSet(it.id,idx,"kg",v.replace(",","."))}} keyboardType="decimal-pad" placeholder="kg" placeholderTextColor="#B0B0B5" style={styles.inputCompact} /></View> : null}
      {(inputType === "kg_reps") ? <View style={{flex:1,marginRight:8}}><TextInput value={s.reps} onChangeText={function(v){updateWorkoutSet(it.id,idx,"reps",v.replace(/[^\d]/g,""))}} keyboardType="number-pad" placeholder="reps" placeholderTextColor="#B0B0B5" style={styles.inputCompact} /></View> : null}
      {(inputType === "reps") ? <View style={{flex:1,marginRight:8}}><TextInput value={s.reps} onChangeText={function(v){updateWorkoutSet(it.id,idx,"reps",v.replace(/[^\d]/g,""))}} keyboardType="number-pad" placeholder="reps" placeholderTextColor="#B0B0B5" style={styles.inputCompact} /></View> : null}
      {(inputType === "kg_dist" || inputType === "dist") ? <View style={{flex:1,marginRight:8}}><TextInput value={s.dist||""} onChangeText={function(v){updateWorkoutSet(it.id,idx,"dist",v.replace(/[^\d]/g,""))}} keyboardType="number-pad" placeholder="m" placeholderTextColor="#B0B0B5" style={styles.inputCompact} /></View> : null}
      {(inputType === "duration") ? <View style={{flex:1,marginRight:8}}><TextInput value={s.duration||""} onChangeText={function(v){updateWorkoutSet(it.id,idx,"duration",v.replace(/[^\d]/g,""))}} keyboardType="number-pad" placeholder="min" placeholderTextColor="#B0B0B5" style={styles.inputCompact} /></View> : null}
      {(inputType === "time_sec") ? <View style={{flex:1,marginRight:8}}><TextInput value={s.duration||""} onChangeText={function(v){updateWorkoutSet(it.id,idx,"duration",v.replace(/[^\d]/g,""))}} keyboardType="number-pad" placeholder="sek" placeholderTextColor="#B0B0B5" style={styles.inputCompact} /></View> : null}
      <PulsePressable onPress={function(){toggleDone(it.id,idx)}} style={styles.doneBtnSmall}><Text style={styles.doneBtnSmallText}>Done</Text></PulsePressable>
    </View>);
  }

  return (<ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
    <View style={styles.rowBetween}><Text style={styles.h1}>{plan.name}</Text><PillButton label="Abbrechen" onPress={() => setWorkout(null)} variant="secondary" /></View>
    <View style={styles.rowBetween}>
      <View style={[styles.statBox, { marginRight: 10 }]}><Text style={styles.statLabel}>Sets</Text><Text style={styles.statValue}>{totals.doneSets}/{totals.totalSets}</Text></View>
      <View style={[styles.statBox, { marginRight: 10, backgroundColor: restRemaining > 0 ? "rgba(68,142,255,0.08)" : "rgba(0,0,0,0.03)" }]}><Text style={styles.statLabel}>Pause</Text><Text style={styles.statValue}>{formatMMSS(restRemaining)}</Text></View>
    </View>
    <View style={[styles.rowWrap, {marginTop: 8, marginBottom: 8}]}>
      <Chip label="1:30" active={false} onPress={function(){startRest(90)}} />
      <Chip label="3:00" active={false} onPress={function(){startRest(180)}} />
      <Chip label="5:00" active={false} onPress={function(){startRest(300)}} />
      {restRemaining > 0 ? <Chip label="Skip" active={false} onPress={clearRest} /> : null}
    </View>
    {(function() { var lastSec = ""; return items.map(function(it) { var sets = workout.sets[it.id] || []; var showSec = it.section && it.section !== lastSec; lastSec = it.section || lastSec; var allDone = sets.length > 0 && sets.every(function(s){return s.done}); var isActive = it.id === activeItemId; var isOpen = expandedEx === it.id;
      return (<React.Fragment key={it.id}>{showSec ? <SectionDivider label={it.section} /> : null}
        <Pressable onPress={function(){setExpandedEx(isOpen?null:it.id)}} style={[styles.planItemCompact, isActive ? styles.activeExercise : null, allDone ? {opacity:0.45} : null]}>
          <View style={styles.rowBetween}>
            <Text style={styles.listTitle}>{it.exercise.name}</Text>
            <View style={{flexDirection:"row",alignItems:"center"}}>
              {allDone ? <Text style={{color:"#2ECC8D",fontWeight:"800",fontSize:12,marginRight:8}}>OK</Text> : null}
              <Pressable onPress={function(e){e.stopPropagation&&e.stopPropagation();setHowtoEx(it.exercise)}} hitSlop={8}><Text style={{color:"#448EFF",fontWeight:"700",fontSize:13}}>i</Text></Pressable>
            </View>
          </View>
          {isOpen ? <View style={{marginTop:8}}>{sets.map(function(s,idx){ return renderSetInput(it,s,idx); })}
            {(function(){ var msgs = []; sets.forEach(function(s,idx){ var m = (workout.suggestions||{})[it.id+"_"+idx]; if(m) msgs.push(m); }); if(msgs.length===0) return null; return <Text style={msgs.some(function(m){return m.indexOf("MAX")>=0}) ? styles.prText : styles.suggestionText}>{msgs[msgs.length-1]}</Text>; })()}
          </View> : <Text style={styles.compactMeta}>{sets.filter(function(s){return s.done}).length}/{sets.length} Sets</Text>}
        </Pressable></React.Fragment>); }); })()}
    <Pressable onPress={onFinish} style={styles.bigButton}><Text style={styles.bigButtonText}>Workout beenden</Text></Pressable>
    <Modal visible={!!howtoEx} animationType="slide" onRequestClose={function(){setHowtoEx(null)}}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>{howtoEx?.name||""}</Text><PillButton label="Fertig" onPress={function(){setHowtoEx(null)}} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title="Ausfuehrung">{(howtoEx?.howto||[]).length === 0 ? <Text style={styles.muted}>Keine Tipps hinterlegt.</Text> : (howtoEx?.howto||[]).map(function(tip,i){return <Text key={i} style={styles.howtoItem}>{"  "+String(i+1)+". "+tip}</Text>})}</GlassCard><GlassCard title="Details"><Text style={styles.listMeta}>{(howtoEx?.category||"")+" - "+(howtoEx?.muscle||"")}</Text><Text style={styles.listMeta}>Input: {howtoEx?.inputType||"kg_reps"}</Text></GlassCard></ScrollView></SafeAreaView></Modal>
  </ScrollView>);
}


function CalendarScreen({ t, plans, calendarEntries, setCalendarEntries, calendarTemplates, setCalendarTemplates, calendarWeekOffset, setCalendarWeekOffset, onApplyTemplatesToWeek }) {
  const [entryModalOpen, setEntryModalOpen] = useState(false); const [templateModalOpen, setTemplateModalOpen] = useState(false);
  const [editingEntryId, setEditingEntryId] = useState(null);
  const [entryDate, setEntryDate] = useState(""); const [entryTime, setEntryTime] = useState("07:00"); const [entryDuration, setEntryDuration] = useState("45"); const [entryTitle, setEntryTitle] = useState(""); const [entrySportType, setEntrySportType] = useState("Gym"); const [entryPlanId, setEntryPlanId] = useState(""); const [entryStatus, setEntryStatus] = useState("planned");
  const [templateTitle, setTemplateTitle] = useState(""); const [templateSportType, setTemplateSportType] = useState("Gym"); const [templateWeekday, setTemplateWeekday] = useState(1); const [templateTime, setTemplateTime] = useState("07:00"); const [templateDuration, setTemplateDuration] = useState("45"); const [templatePlanId, setTemplatePlanId] = useState(""); const [templateNotes, setTemplateNotes] = useState("");
  const today = new Date(); const weekStart = addDays(startOfWeekMonday(today), calendarWeekOffset * 7); const weekDays = Array.from({ length: 7 }).map((_, i) => addDays(weekStart, i));
  function openNewEntry(day) { setEditingEntryId(null); setEntryDate(formatDateKey(day)); setEntryTime("07:00"); setEntryDuration("45"); setEntryTitle(""); setEntrySportType("Gym"); setEntryPlanId(""); setEntryStatus("planned"); setEntryModalOpen(true); }
  function openEditEntry(e) { setEditingEntryId(e.id); setEntryDate(e.date || ""); setEntryTime(e.startTime || "07:00"); setEntryDuration(String(e.durationMin || 45)); setEntryTitle(e.title || ""); setEntrySportType(e.sportType || "Other"); setEntryPlanId(e.planId || ""); setEntryStatus(e.status || "planned"); setEntryModalOpen(true); }
  function saveEntry() { const date = String(entryDate || "").trim(); const title = String(entryTitle || "").trim(); if (!parseDateKey(date) || !title) return; const now = Date.now(); setCalendarEntries((prev) => { const existing = editingEntryId ? prev.find((x) => x.id === editingEntryId) : null; const obj = { id: editingEntryId || uid(), date, startTime: entryTime || "07:00", durationMin: Math.max(1, parseInt(entryDuration || "45", 10) || 45), title, sportType: entrySportType || "Other", planId: entrySportType === "Gym" ? (entryPlanId || null) : null, status: entryStatus || "planned", templateId: existing?.templateId || null, createdAt: existing?.createdAt || now, updatedAt: now }; if (editingEntryId) return prev.map((x) => (x.id === editingEntryId ? { ...x, ...obj } : x)); return [obj, ...prev]; }); setEntryModalOpen(false); }
  function deleteEntry(id) { setCalendarEntries((prev) => prev.filter((x) => x.id !== id)); }
  function copyEntryNextWeek(id) { setCalendarEntries((prev) => { const src = prev.find((x) => x.id === id); if (!src) return prev; const d = parseDateKey(src.date); if (!d) return prev; const targetDate = formatDateKey(addDays(d, 7)); const exists = prev.some((x) => x.date === targetDate && x.title === src.title && x.startTime === src.startTime); if (exists) return prev; const now = Date.now(); return [{ ...src, id: uid(), date: targetDate, status: "planned", createdAt: now, updatedAt: now }, ...prev]; }); }
  function moveEntryTomorrow(id) { setCalendarEntries((prev) => prev.map((x) => { if (x.id !== id) return x; const d = parseDateKey(x.date); if (!d) return x; return { ...x, date: formatDateKey(addDays(d, 1)), updatedAt: Date.now(), status: x.status === "done" ? "planned" : x.status }; })); }
  function saveTemplate() { const title = String(templateTitle || "").trim(); if (!title) return; const now = Date.now(); setCalendarTemplates((prev) => [{ id: uid(), title, sportType: templateSportType || "Other", weekday: Math.min(7, Math.max(1, parseInt(String(templateWeekday), 10) || 1)), startTime: templateTime || "07:00", durationMin: Math.max(1, parseInt(templateDuration || "45", 10) || 45), planId: templateSportType === "Gym" ? (templatePlanId || null) : null, notes: templateNotes || "", active: true, createdAt: now, updatedAt: now }, ...prev]); setTemplateModalOpen(false); setTemplateTitle(""); setTemplateNotes(""); }
  function toggleTemplate(id) { setCalendarTemplates((prev) => prev.map((x) => (x.id === id ? { ...x, active: !x.active, updatedAt: Date.now() } : x))); }
  const weekdayLabel = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
  function entriesForDate(dateKey) { return calendarEntries.filter((e) => e.date === dateKey).sort((a, b) => parseTimeToMin(a.startTime) - parseTimeToMin(b.startTime)); }

  return (<ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
    <GlassCard title="Week Planner"><View style={styles.rowBetween}><Text style={styles.listTitle}>{getWeekRangeLabel(weekStart)}</Text><View style={{ flexDirection: "row" }}><PillButton label="<" onPress={() => setCalendarWeekOffset((v) => v - 1)} variant="secondary" /><PillButton label="Heute" onPress={() => setCalendarWeekOffset(0)} variant="secondary" /><PillButton label=">" onPress={() => setCalendarWeekOffset((v) => v + 1)} variant="secondary" /></View></View></GlassCard>
    <GlassCard title="Templates"><View style={styles.rowWrap}><PillButton label="+ Template" onPress={() => setTemplateModalOpen(true)} variant="secondary" /><PillButton label="Woche füllen" onPress={() => onApplyTemplatesToWeek(weekStart)} variant="primary" /></View>{calendarTemplates.length === 0 ? <Text style={styles.muted}>No templates yet.</Text> : calendarTemplates.map((tpl) => (<View key={tpl.id} style={styles.listItemRow}><View style={{ flex: 1 }}><Text style={styles.listTitle}>{tpl.title}</Text><Text style={styles.listMeta}>{weekdayLabel[(tpl.weekday || 1) - 1]} - {tpl.startTime} - {tpl.durationMin} min - {tpl.sportType} {tpl.active ? "- ok" : "- off"}</Text></View><PillButton label={tpl.active ? "Off" : "On"} onPress={() => toggleTemplate(tpl.id)} variant="secondary" /></View>))}</GlassCard>
    {weekDays.map(function(d) { var dateKey = formatDateKey(d); var entries = entriesForDate(dateKey); return (<GlassCard key={dateKey} title={weekdayLabel[weekdayMonday1to7(d) - 1] + " - " + dateKey}><View style={styles.rowWrap}><RowButton label="+ Add" onPress={() => openNewEntry(d)} variant="secondary" /></View>{entries.length === 0 ? <ListEmpty text={t.calendar.empty} /> : entries.map(function(e) { return (<View key={e.id} style={styles.planItem}><Text style={styles.listTitle}>{e.title}</Text><Text style={styles.listMeta}>{e.startTime} - {e.durationMin} min - {e.sportType} - {e.status}</Text><View style={styles.rowWrap}><RowButton label="Edit" onPress={() => openEditEntry(e)} variant="secondary" /><RowButton label="Del" onPress={() => deleteEntry(e.id)} variant="secondary" /><RowButton label="> Na. Woche" onPress={() => copyEntryNextWeek(e.id)} variant="secondary" /><RowButton label="> Morgen" onPress={() => moveEntryTomorrow(e.id)} variant="secondary" /></View></View>); })}</GlassCard>); })}

    <Modal visible={entryModalOpen} animationType="slide" onRequestClose={() => setEntryModalOpen(false)}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>{editingEntryId ? "Edit Entry" : "New Entry"}</Text><PillButton label={t.today.close} onPress={() => setEntryModalOpen(false)} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title="Entry"><Text style={styles.label}>Date (YYYY-MM-DD)</Text><TextInput value={entryDate} onChangeText={setEntryDate} style={styles.input} placeholder="2026-03-10" placeholderTextColor="#8B8B93" autoCapitalize="none" /><Text style={styles.label}>Title</Text><TextInput value={entryTitle} onChangeText={setEntryTitle} style={styles.input} placeholder="Run Zone 2" placeholderTextColor="#8B8B93" /><Text style={styles.label}>Sport</Text><View style={styles.rowWrap}>{SPORT_TYPES.map((x) => <Chip key={x} label={x} active={entrySportType === x} onPress={() => setEntrySportType(x)} />)}</View><View style={styles.setRow}><View style={{ flex: 1, marginRight: 10 }}><Text style={styles.label}>Start</Text><TextInput value={entryTime} onChangeText={setEntryTime} style={styles.inputSmall} placeholder="07:00" placeholderTextColor="#8B8B93" autoCapitalize="none" /></View><View style={{ flex: 1 }}><Text style={styles.label}>Duration</Text><TextInput value={entryDuration} onChangeText={(v) => setEntryDuration(v.replace(/[^\d]/g, ""))} style={styles.inputSmall} placeholder="45" placeholderTextColor="#8B8B93" keyboardType="number-pad" /></View></View>{entrySportType === "Gym" ? (<><Text style={styles.label}>Plan</Text><View style={styles.rowWrap}><Chip label="None" active={!entryPlanId} onPress={() => setEntryPlanId("")} />{plans.map((pl) => <Chip key={pl.id} label={pl.name} active={entryPlanId === pl.id} onPress={() => setEntryPlanId(pl.id)} />)}</View></>) : null}<Text style={styles.label}>Status</Text><View style={styles.rowWrap}>{["planned", "done", "skipped"].map((st) => <Chip key={st} label={st} active={entryStatus === st} onPress={() => setEntryStatus(st)} />)}</View><View style={styles.rowWrap}><PillButton label="Save" onPress={saveEntry} variant="primary" /></View></GlassCard></ScrollView></SafeAreaView></Modal>
    <Modal visible={templateModalOpen} animationType="slide" onRequestClose={() => setTemplateModalOpen(false)}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>New Template</Text><PillButton label={t.today.close} onPress={() => setTemplateModalOpen(false)} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title="Template"><Text style={styles.label}>Title</Text><TextInput value={templateTitle} onChangeText={setTemplateTitle} style={styles.input} placeholder="Tue Full Body" placeholderTextColor="#8B8B93" /><Text style={styles.label}>Sport</Text><View style={styles.rowWrap}>{SPORT_TYPES.map((x) => <Chip key={x} label={x} active={templateSportType === x} onPress={() => setTemplateSportType(x)} />)}</View><Text style={styles.label}>Weekday</Text><View style={styles.rowWrap}>{weekdayLabel.map((w, idx) => <Chip key={w} label={w} active={templateWeekday === idx + 1} onPress={() => setTemplateWeekday(idx + 1)} />)}</View><View style={styles.setRow}><View style={{ flex: 1, marginRight: 10 }}><Text style={styles.label}>Start</Text><TextInput value={templateTime} onChangeText={setTemplateTime} style={styles.inputSmall} placeholder="07:00" placeholderTextColor="#8B8B93" autoCapitalize="none" /></View><View style={{ flex: 1 }}><Text style={styles.label}>Duration</Text><TextInput value={templateDuration} onChangeText={(v) => setTemplateDuration(v.replace(/[^\d]/g, ""))} style={styles.inputSmall} placeholder="45" placeholderTextColor="#8B8B93" keyboardType="number-pad" /></View></View>{templateSportType === "Gym" ? (<><Text style={styles.label}>Plan</Text><View style={styles.rowWrap}><Chip label="None" active={!templatePlanId} onPress={() => setTemplatePlanId("")} />{plans.map((pl) => <Chip key={pl.id} label={pl.name} active={templatePlanId === pl.id} onPress={() => setTemplatePlanId(pl.id)} />)}</View></>) : null}<Text style={styles.label}>Notes</Text><TextInput value={templateNotes} onChangeText={setTemplateNotes} style={styles.input} placeholder="optional" placeholderTextColor="#8B8B93" multiline /><View style={styles.rowWrap}><PillButton label="Save Template" onPress={saveTemplate} variant="primary" /></View></GlassCard></ScrollView></SafeAreaView></Modal>
  </ScrollView>);
}


/** Endurance Modals + Screen */
function EnduranceTemplateModal({ visible, onClose, plans, onSave, initial }) {
  const [name, setName] = useState(""); const [sportType, setSportType] = useState("Run"); const [workoutType, setWorkoutType] = useState("Zone2"); const [durationMin, setDurationMin] = useState("45"); const [distanceKm, setDistanceKm] = useState(""); const [planId, setPlanId] = useState(""); const [notes, setNotes] = useState(""); const [intervalText, setIntervalText] = useState("");
  useEffect(() => { if (!visible) return; setName(initial?.name || ""); setSportType(initial?.sportType || "Run"); setWorkoutType(initial?.workoutType || "Zone2"); setDurationMin(String(initial?.target?.durationMin || 45)); setDistanceKm(initial?.target?.distanceKm ? String(initial.target.distanceKm) : ""); setPlanId(initial?.planId || ""); setNotes(initial?.notes || ""); setIntervalText((initial?.intervals || []).map((x) => `${x.kind},${x.durationSec || 0},${x.targetText || ""}`).join("\n")); }, [visible, initial]);
  function save() { const n = name.trim(); if (!n) return; const lines = intervalText.split(/\n+/).map((x) => x.trim()).filter(Boolean); const intervals = lines.map((line) => { const [kindRaw, secRaw, targetRaw] = line.split(","); return { id: uid(), kind: kindRaw === "rest" ? "rest" : "work", durationSec: Math.max(1, parseInt(String(secRaw || "0"), 10) || 0), targetText: String(targetRaw || "").trim() }; }).filter((x) => x.durationSec > 0); onSave({ id: initial?.id || uid(), name: n, sportType, workoutType, target: { durationMin: Math.max(1, parseInt(durationMin || "45", 10) || 45), distanceKm: distanceKm ? Number(distanceKm.replace(",", ".")) : undefined }, intervals: intervals.length ? intervals : undefined, notes, planId: sportType === "Gym" ? (planId || null) : null, createdAt: initial?.createdAt || Date.now(), updatedAt: Date.now() }); onClose(); }
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>Template</Text><PillButton label="Schließen" onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title="Basics"><TextInput value={name} onChangeText={setName} placeholder="Zone 2 45min" placeholderTextColor="#8B8B93" style={styles.input} /><Text style={styles.label}>Sport</Text><View style={styles.rowWrap}>{SPORT_TYPES.map((x) => <Chip key={x} label={x} active={sportType===x} onPress={() => setSportType(x)} />)}</View><Text style={styles.label}>Type</Text><View style={styles.rowWrap}>{["Zone2","Intervals","Tempo","Long","Recovery","Race","Other"].map((x) => <Chip key={x} label={x} active={workoutType===x} onPress={() => setWorkoutType(x)} />)}</View><View style={styles.setRow}><View style={{ flex: 1, marginRight: 10 }}><Text style={styles.smallLabel}>duration min</Text><TextInput value={durationMin} onChangeText={(v) => setDurationMin(v.replace(/[^\d]/g,""))} keyboardType="number-pad" style={styles.inputSmall} /></View><View style={{ flex: 1 }}><Text style={styles.smallLabel}>distance km</Text><TextInput value={distanceKm} onChangeText={(v) => setDistanceKm(v.replace(/[^\d.]/g,""))} keyboardType="decimal-pad" style={styles.inputSmall} /></View></View></GlassCard><GlassCard title="Intervals (optional)"><Text style={styles.help}>Format: work,120,5k pace oder rest,60,easy</Text><TextInput value={intervalText} onChangeText={setIntervalText} multiline style={[styles.input,{minHeight:120}]} autoCapitalize="none" /><Text style={styles.label}>Notes</Text><TextInput value={notes} onChangeText={setNotes} multiline style={styles.input} /><View style={styles.rowWrap}><PillButton label="Save" onPress={save} variant="primary" /></View></GlassCard></ScrollView></SafeAreaView></Modal>);
}

function EnduranceScheduleModal({ visible, onClose, template, onSchedule }) {
  const [date, setDate] = useState(formatDateKey(new Date())); const [time, setTime] = useState("07:00");
  useEffect(() => { if (visible) { setDate(formatDateKey(new Date())); setTime(template?.target?.startTime || "07:00"); } }, [visible, template]);
  if (!template) return null;
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>Schedule</Text><PillButton label="Close" onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title={template.name}><Text style={styles.label}>Date</Text><TextInput value={date} onChangeText={setDate} style={styles.input} autoCapitalize="none" /><Text style={styles.label}>Start time</Text><TextInput value={time} onChangeText={setTime} style={styles.input} autoCapitalize="none" /><View style={styles.rowWrap}><PillButton label="Create calendar entry" onPress={() => { onSchedule(template, date, time); onClose(); }} variant="primary" /></View></GlassCard></ScrollView></SafeAreaView></Modal>);
}

function EnduranceSessionDetailModal({ visible, onClose, session }) {
  if (!session) return null;
  const m = enduranceMetricLabel(session.sportType, session.actual?.durationMin, session.actual?.distanceKm);
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>Endurance Session</Text><PillButton label="Close" onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title={session.title}><Text style={styles.listMeta}>{session.sportType} - {session.workoutType} - {session.date}</Text><Text style={styles.help}>Duration: {session.actual?.durationMin || "-"} min - Distance: {session.actual?.distanceKm || "-"} km - {m}</Text><Text style={styles.help}>RPE: {session.actual?.rpe || "-"} - HR: {session.actual?.avgHr || "-"}</Text>{session.actual?.notes ? <Text style={styles.help}>{session.actual.notes}</Text> : null}</GlassCard></ScrollView></SafeAreaView></Modal>);
}

function EnduranceWorkoutScreen({ workout, setWorkout, onFinish }) {
  const timerRef = useRef(null);
  useEffect(() => { if (!workout?.running) return; timerRef.current = setInterval(() => { setWorkout((prev) => { if (!prev || !prev.running) return prev; if (prev.mode === "intervals") { return { ...prev, currentRemainingSec: prev.currentRemainingSec <= 1 ? 0 : prev.currentRemainingSec - 1, elapsedSec: (prev.elapsedSec || 0) + 1 }; } return { ...prev, elapsedSec: (prev.elapsedSec || 0) + 1 }; }); }, 1000); return () => { if (timerRef.current) clearInterval(timerRef.current); timerRef.current = null; }; }, [workout?.running, setWorkout]);
  if (!workout) return null;
  const intervals = workout.intervals || []; const current = intervals[workout.currentIndex || 0] || null;
  function doneBlock() { setWorkout((prev) => { if (!prev) return prev; const arr = (prev.intervalsPerformed || []).map((x) => ({ ...x })); if (arr[prev.currentIndex]) arr[prev.currentIndex] = { ...arr[prev.currentIndex], done: true, actualDurationSec: arr[prev.currentIndex].plannedDurationSec }; const nextIdx = (prev.currentIndex || 0) + 1; if (nextIdx >= (prev.intervals || []).length) return { ...prev, intervalsPerformed: arr, running: false, currentRemainingSec: 0 }; const nextPlanned = prev.intervals[nextIdx]?.durationSec || 0; return { ...prev, intervalsPerformed: arr, currentIndex: nextIdx, currentRemainingSec: nextPlanned }; }); }
  return (<SafeAreaView style={styles.root}><ScrollView contentContainerStyle={styles.screenPad}><View style={styles.rowBetween}><Text style={styles.h1}>Endurance</Text><PillButton label="Back" onPress={() => setWorkout(null)} variant="secondary" /></View><GlassCard title={workout.title}><Text style={styles.listMeta}>{workout.sportType} - {workout.workoutType}</Text><Text style={styles.timerBig}>{formatMMSS(workout.mode === "intervals" ? workout.currentRemainingSec || 0 : workout.elapsedSec || 0)}</Text><Text style={styles.help}>Elapsed: {formatMMSS(workout.elapsedSec || 0)}</Text>{workout.mode === "intervals" && current ? <Text style={styles.help}>Current: {current.kind} {current.targetText ? `- ${current.targetText}` : ""}</Text> : null}<View style={styles.rowWrap}><PillButton label={workout.running ? "Pause" : "Start"} onPress={() => setWorkout((p) => ({ ...p, running: !p.running }))} variant="primary" />{workout.mode === "intervals" ? <PillButton label="Done Block" onPress={doneBlock} variant="secondary" /> : null}<PillButton label="Finish" onPress={() => onFinish(workout)} variant="secondary" /></View></GlassCard></ScrollView></SafeAreaView>);
}

function EnduranceScreen({ templates, sessions, plans, onSaveTemplate, onDeleteTemplate, onStartTemplate, onScheduleTemplate, onOpenSession }) {
  const [templateModalOpen, setTemplateModalOpen] = useState(false); const [editingTemplate, setEditingTemplate] = useState(null);
  const [scheduleOpen, setScheduleOpen] = useState(false); const [scheduleTemplate, setScheduleTemplate] = useState(null);
  return (<ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
    <GlassCard title="Endurance Templates"><View style={styles.rowWrap}><PillButton label="+ Template" onPress={() => { setEditingTemplate(null); setTemplateModalOpen(true); }} variant="primary" /></View>{templates.length === 0 ? <Text style={styles.muted}>No templates yet.</Text> : templates.map((tpl) => (<View key={tpl.id} style={styles.planItem}><Text style={styles.listTitle}>{tpl.name}</Text><Text style={styles.listMeta}>{tpl.sportType} - {tpl.workoutType} - {tpl.target?.durationMin || "-"} min</Text>{tpl.notes ? <Text style={styles.help}>{tpl.notes}</Text> : null}<View style={styles.rowWrap}><PillButton label="Start" onPress={() => onStartTemplate(tpl)} variant="secondary" /><PillButton label="Schedule" onPress={() => { setScheduleTemplate(tpl); setScheduleOpen(true); }} variant="secondary" /><PillButton label="Edit" onPress={() => { setEditingTemplate(tpl); setTemplateModalOpen(true); }} variant="secondary" /><PillButton label="Del" onPress={() => onDeleteTemplate(tpl.id)} variant="secondary" /></View></View>))}</GlassCard>
    <GlassCard title="History">{sessions.length === 0 ? <Text style={styles.muted}>No sessions yet.</Text> : sessions.slice(0, 40).map((s) => (<Pressable key={s.id} onPress={() => onOpenSession(s)} style={styles.listItem}><Text style={styles.listTitle}>{s.title}</Text><Text style={styles.listMeta}>{s.date} - {s.sportType} - {s.actual?.durationMin || "-"} min - {enduranceMetricLabel(s.sportType, s.actual?.durationMin, s.actual?.distanceKm)}</Text></Pressable>))}</GlassCard>
    <EnduranceTemplateModal visible={templateModalOpen} onClose={() => setTemplateModalOpen(false)} plans={plans} onSave={onSaveTemplate} initial={editingTemplate} />
    <EnduranceScheduleModal visible={scheduleOpen} onClose={() => setScheduleOpen(false)} template={scheduleTemplate} onSchedule={onScheduleTemplate} />
  </ScrollView>);
}


function ExerciseProgressModal({ visible, onClose, exercise, history }) {
  const [metric, setMetric] = useState("bestKg"); const [range, setRange] = useState("12W");
  if (!exercise) return null;
  const now = Date.now(); const days = range === "4W" ? 28 : range === "12W" ? 84 : 99999;
  const list = (history || []).filter((x) => (now - x.ts) <= days * 24 * 3600 * 1000);
  const latest = history?.[0]; const best = (history || []).reduce((a, b) => ((b?.[metric] || 0) > (a?.[metric] || 0) ? b : a), null);
  const fourW = (history || []).filter((x) => (now - x.ts) <= 28 * 24 * 3600 * 1000);
  const older4W = (history || []).filter((x) => (now - x.ts) > 28 * 24 * 3600 * 1000 && (now - x.ts) <= 56 * 24 * 3600 * 1000);
  const avg = (arr, key) => arr.length ? arr.reduce((s, x) => s + (Number(x?.[key] || 0)), 0) / arr.length : 0;
  const delta4W = avg(fourW, metric) - avg(older4W, metric);
  const maxV = Math.max(1, ...list.map((x) => Number(x?.[metric] || 0)));
  return (<Modal visible={visible} animationType="slide" onRequestClose={onClose}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>{exercise.name}</Text><PillButton label="Close" onPress={onClose} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}>
    <GlassCard title="Summary"><View style={styles.rowWrap}><View style={styles.statMini}><Text style={styles.smallLabel}>Last</Text><Text style={styles.listTitle}>{latest ? latest[metric] : "-"}</Text></View><View style={styles.statMini}><Text style={styles.smallLabel}>Best</Text><Text style={styles.listTitle}>{best ? best[metric] : "-"}</Text></View><View style={styles.statMini}><Text style={styles.smallLabel}>4W D</Text><Text style={styles.listTitle}>{delta4W >= 0 ? "+" : ""}{delta4W.toFixed(1)}</Text></View><View style={styles.statMini}><Text style={styles.smallLabel}>Est 1RM</Text><Text style={styles.listTitle}>{latest?.est1RM || "-"}</Text></View></View></GlassCard>
    <GlassCard title="Chart"><View style={styles.rowWrap}>{[["bestKg","Top kg"],["totalVolume","Volume"],["est1RM","1RM"],["bestReps","Reps"]].map(([k, l]) => <Chip key={k} label={l} active={metric === k} onPress={() => setMetric(k)} />)}</View><View style={styles.rowWrap}>{["4W","12W","All"].map((r) => <Chip key={r} label={r} active={range === r} onPress={() => setRange(r)} />)}</View><View style={styles.trendRow}>{list.slice(0, 16).reverse().map((x) => (<View key={`${x.sessionId}_${x.ts}`} style={styles.trendBarWrap}><View style={[styles.trendBar, { height: Math.max(8, (Number(x?.[metric] || 0) / maxV) * 90) }]} /></View>))}</View></GlassCard>
    <GlassCard title="Sessions">{(history || []).map(function(item) { return (<View key={item.sessionId + "_" + item.ts} style={styles.listItem}><Text style={styles.listTitle}>{item.date}</Text><Text style={styles.listMeta}>Best: {item.bestKg} kg x {item.bestReps} - Vol: {item.totalVolume}</Text></View>); })}</GlassCard>
  </ScrollView></SafeAreaView></Modal>);
}

function ProgressScreen({ sessions, logs, calendarEntries, allExercises, prefs, setPrefs }) {
  const [weekOffset, setWeekOffset] = useState(0); const [selectedDay, setSelectedDay] = useState(formatDateKey(new Date()));
  const [exerciseQ, setExerciseQ] = useState(""); const [exerciseOnlyFav, setExerciseOnlyFav] = useState(false);
  const [exerciseOpen, setExerciseOpen] = useState(false); const [selectedExercise, setSelectedExercise] = useState(null);
  const debouncedExerciseQ = useDebouncedValue(exerciseQ, 250);
  const weekStart = addDays(startOfWeekMonday(new Date()), weekOffset * 7); const weekDays = Array.from({ length: 7 }).map((_, i) => addDays(weekStart, i));
  const sessionsByDay = useMemo(() => { const map = {}; for (const s of sessions || []) { const k = formatDateKey(new Date(s.startedAt)); map[k] = map[k] || []; map[k].push(s); } return map; }, [sessions]);
  const logsByDay = useMemo(() => { const map = {}; for (const l of logs || []) { const k = formatDateKey(new Date(l.createdAt)); map[k] = map[k] || []; map[k].push(l); } return map; }, [logs]);
  const entriesByDay = useMemo(() => { const map = {}; for (const e of calendarEntries || []) { map[e.date] = map[e.date] || []; map[e.date].push(e); } return map; }, [calendarEntries]);
  const stripData = weekDays.map((d) => { const key = formatDateKey(d); const sess = sessionsByDay[key] || []; const planned = entriesByDay[key] || []; return { key, label: d.toLocaleDateString(undefined, { weekday: "short" }), dayNum: d.getDate(), status: sess.length > 0 ? "done" : planned.length > 0 ? "planned" : "none" }; });
  const weekKeys = new Set(stripData.map((x) => x.key));
  let totalWorkouts = 0, totalMinutes = 0, gymSets = 0, volume = 0;
  for (const s of sessions || []) { const k = formatDateKey(new Date(s.startedAt)); if (!weekKeys.has(k)) continue; totalWorkouts += 1; totalMinutes += Number(s.durationMin || 0); gymSets += Number(s.doneSets || 0); volume += Number(s.totalVolumeKg || 0); }
  const trends = useMemo(() => { const arr = []; for (let w = 7; w >= 0; w--) { const start = addDays(startOfWeekMonday(new Date()), -w * 7); const end = addDays(start, 6); let workouts = 0; for (const s of sessions || []) { const d = new Date(s.startedAt); if (d >= start && d <= new Date(end.getFullYear(), end.getMonth(), end.getDate(), 23, 59, 59)) workouts += 1; } arr.push({ k: formatDateKey(start), workouts }); } return arr; }, [sessions]);
  const maxTrend = Math.max(1, ...trends.map((x) => x.workouts));
  const daySessions = sessionsByDay[selectedDay] || []; const dayLogs = logsByDay[selectedDay] || [];
  const historyMap = useMemo(() => buildExerciseHistory(sessions), [sessions]);
  const favMap = prefs?.exerciseFavorites || {};
  const exerciseRows = useMemo(() => { const ids = new Set([...Object.keys(historyMap), ...(allExercises || []).map((x) => x.id)]); const arr = []; for (const id of ids) { const ex = (allExercises || []).find((x) => x.id === id); if (!ex) continue; if (debouncedExerciseQ && !ex.name.toLowerCase().includes(debouncedExerciseQ.toLowerCase())) continue; if (exerciseOnlyFav && !favMap[id]) continue; const h = historyMap[id] || []; const latest = h[0]; const prev = h[1]; arr.push({ id, ex, count: h.length, latest, trend: latest && prev ? latest.bestKg - prev.bestKg : 0 }); } arr.sort((a, b) => (b.count - a.count) || a.ex.name.localeCompare(b.ex.name)); return arr; }, [historyMap, allExercises, debouncedExerciseQ, exerciseOnlyFav, favMap]);

  return (<ScrollView contentContainerStyle={styles.screenPad}><Text style={styles.h1}>Progress</Text>
    <GlassCard title="Week Strip"><View style={styles.rowBetween}><PillButton label="<" onPress={() => setWeekOffset((v) => v - 1)} variant="secondary" /><Text style={styles.listMeta}>{getWeekRangeLabel(weekStart)}</Text><PillButton label=">" onPress={() => setWeekOffset((v) => v + 1)} variant="secondary" /></View><ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 10 }}>{stripData.map(function(item) { return (<Pressable key={item.key} onPress={() => setSelectedDay(item.key)} style={[styles.progressDayChip, selectedDay === item.key ? styles.progressDayChipActive : null]}><Text style={styles.smallLabel}>{item.label}</Text><Text style={styles.listTitle}>{item.dayNum}</Text><View style={[styles.progressDot, item.status === "done" ? styles.progressDone : item.status === "planned" ? styles.progressPlanned : styles.progressNone]} /></Pressable>); })}</ScrollView></GlassCard>
    <GlassCard title="Week Summary"><View style={styles.rowWrap}><View style={styles.statMini}><Text style={styles.smallLabel}>Workouts</Text><Text style={styles.listTitle}>{totalWorkouts}</Text></View><View style={styles.statMini}><Text style={styles.smallLabel}>Minutes</Text><Text style={styles.listTitle}>{totalMinutes}</Text></View><View style={styles.statMini}><Text style={styles.smallLabel}>Sets</Text><Text style={styles.listTitle}>{gymSets}</Text></View><View style={styles.statMini}><Text style={styles.smallLabel}>Volume</Text><Text style={styles.listTitle}>{Math.round(volume)}</Text></View></View></GlassCard>
    <GlassCard title="Trend (8W)"><View style={styles.trendRow}>{trends.map((x) => (<View key={x.k} style={styles.trendBarWrap}><View style={[styles.trendBar, { height: Math.max(8, (x.workouts / maxTrend) * 90) }]} /><Text style={styles.trendLabel}>{x.workouts}</Text></View>))}</View></GlassCard>
    <GlassCard title={selectedDay}>{(function() { var items = [].concat(daySessions.map(function(s){return {type:"session",id:s.id,title:s.planName,meta:s.doneSets+"/"+s.totalSets+" sets - "+s.durationMin+" min"}}), dayLogs.map(function(l){return {type:"log",id:l.id,title:l.type,meta:l.note||"Log"}})); return items.length === 0 ? <Text style={styles.muted}>Keine Eintraege.</Text> : items.map(function(item){return (<View key={item.type+"_"+item.id} style={styles.listItem}><Text style={styles.listTitle}>{item.title}</Text><Text style={styles.listMeta}>{item.meta}</Text></View>)}); })()}</GlassCard>
    <GlassCard title="Exercise Progress"><GlowTextInput value={exerciseQ} onChangeText={setExerciseQ} placeholder="Search exercise..." placeholderTextColor="#8B8B93" style={styles.input} /><View style={styles.rowWrap}><Chip label={exerciseOnlyFav ? "* Favorites" : "All"} active={exerciseOnlyFav} onPress={() => setExerciseOnlyFav((v) => !v)} /></View>{exerciseRows.length === 0 ? <Text style={styles.muted}>No exercises found.</Text> : exerciseRows.slice(0, 120).map(function(item) { return (<Pressable key={item.id} style={styles.listItemRow} onPress={() => { setSelectedExercise(item.ex); setExerciseOpen(true); }}><View style={{ flex: 1 }}><Text style={styles.listTitle}>{item.ex.name}</Text><Text style={styles.listMeta}>Sessions: {item.count} - {item.latest ? item.latest.bestKg+"kg" : "-"}</Text></View><Text style={[styles.listMeta, { fontWeight: "800", color: item.trend >= 0 ? "#2ECC8D" : "#9A2C2C" }]}>{item.trend >= 0 ? "+" : "-"} {Math.abs(item.trend).toFixed(1)}</Text><Pressable onPress={() => setPrefs((p) => ({ ...p, exerciseFavorites: { ...(p.exerciseFavorites || {}), [item.id]: !p?.exerciseFavorites?.[item.id] } }))} style={{ marginLeft: 10 }}><Text style={styles.listTitle}>{favMap[item.id] ? "*" : "o"}</Text></Pressable></Pressable>); })}</GlassCard>
    <ExerciseProgressModal visible={exerciseOpen} onClose={() => setExerciseOpen(false)} exercise={selectedExercise} history={selectedExercise ? (historyMap[selectedExercise.id] || []) : []} />
  </ScrollView>);
}

function LibraryScreen({ t, allExercises, userExercises, onDeleteUserExercise, onOpenCreate, onOpenImportExercises, onOpenExport, onOpenImportData, packInstalling, packStatusText, onInstallPack, prefs, setPrefs, onOpenExerciseDetail }) {
  const [q, setQ] = useState(""); const [cat, setCat] = useState("All"); const [mus, setMus] = useState("All");
  const debouncedQ = useDebouncedValue(q, 250);
  const filtered = useMemo(() => smartSearch(allExercises, debouncedQ, cat, mus, 60), [allExercises, debouncedQ, cat, mus]);
  return (<ScrollView contentContainerStyle={styles.screenPad} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag"><Text style={styles.h1}>{t.library.title}</Text>
    <GlassCard title={t.library.search}><GlowTextInput value={q} onChangeText={setQ} placeholder={t.library.search} placeholderTextColor="#8B8B93" style={styles.input} autoCapitalize="none" autoCorrect={false} /><Text style={styles.label}>{t.library.filters.category}</Text><View style={styles.rowWrap}>{CATEGORIES.map((x) => <Chip key={x} label={x} active={cat === x} onPress={() => setCat(x)} />)}</View><Text style={styles.label}>{t.library.filters.muscle}</Text><View style={styles.rowWrap}>{MUSCLES.map((x) => <Chip key={x} label={x} active={mus === x} onPress={() => setMus(x)} />)}</View></GlassCard>
    <GlassCard title="Ergebnisse">{filtered.length === 0 ? <ListEmpty text={t.library.noResults} /> : filtered.map(function(e) { return (<Pressable key={e.id} style={styles.listItem} onPress={() => onOpenExerciseDetail(e)}><Text style={styles.listTitle}>{e.name}{e.source && e.source !== "base" ? <Text style={styles.badge}> - {e.source}</Text> : null}</Text><Text style={styles.listMeta}>{e.category} - {e.muscle}</Text></Pressable>); })}</GlassCard>
    <GlassCard title="Defaults"><View style={styles.rowWrap}><PillButton label={`Auto-fill: ${prefs.autoFillFromLastSession ? "On" : "Off"}`} onPress={() => setPrefs((p) => ({ ...p, autoFillFromLastSession: !p.autoFillFromLastSession }))} variant="secondary" /></View><Text style={styles.smallLabel}>Default Rest (sec)</Text><TextInput value={String(prefs.defaultRestSeconds || "")} onChangeText={(v) => setPrefs((p) => ({ ...p, defaultRestSeconds: Number(v.replace(/[^\d]/g, "")) || 0 }))} keyboardType="number-pad" style={styles.inputSmall} /></GlassCard>
    <GlassCard title={t.library.customTitle}><View style={styles.rowWrap}><PillButton label={t.library.addCustom} onPress={onOpenCreate} variant="primary" /></View>{userExercises.length === 0 ? <ListEmpty text={t.library.emptyCustom} /> : userExercises.slice(0, 30).map(function(e) { return (<View key={e.id} style={styles.listItemRow}><View style={{ flex: 1 }}><Text style={styles.listTitle}>{e.name}</Text><Text style={styles.listMeta}>{e.category} - {e.muscle}</Text></View><RowButton label={t.library.delete} onPress={() => onDeleteUserExercise(e.id)} variant="secondary" /></View>); })}</GlassCard>
    <GlassCard title={t.library.dataTitle}><View style={styles.rowWrap}><PillButton label={t.library.importExercises} onPress={onOpenImportExercises} variant="secondary" /><PillButton label={t.library.exportData} onPress={onOpenExport} variant="secondary" /><PillButton label={t.library.importData} onPress={onOpenImportData} variant="secondary" /></View><Text style={styles.help}>{t.library.tip}</Text></GlassCard>
    <GlassCard title="Exercise Pack (800+)"><Text style={styles.listMeta}>Free Exercise DB > riesige Bibliothek + bessere Suche.</Text><View style={styles.rowWrap}><PillButton label={packInstalling ? "Installing..." : "Install Free Exercise DB"} onPress={onInstallPack} variant="primary" /></View>{packInstalling ? (<View style={{ flexDirection: "row", alignItems: "center", marginTop: 10 }}><ActivityIndicator /><Text style={[styles.help, { marginTop: 0, marginLeft: 10 }]}>{packStatusText}</Text></View>) : packStatusText ? <Text style={styles.help}>{packStatusText}</Text> : null}</GlassCard>
  </ScrollView>);
}

/** Planner Tab = Calendar + Endurance combined */
function PlannerScreen({ calendarProps, enduranceProps }) {
  const [subTab, setSubTab] = useState("calendar");
  return (<View style={{ flex: 1 }}>
    <View style={{ paddingHorizontal: DS.spacing.l, paddingTop: DS.spacing.m }}>
      <Text style={styles.h1}>Planer</Text>
      <View style={[styles.rowWrap, { marginBottom: 4, marginTop: -4 }]}>
        <Chip label="Kalender" active={subTab === "calendar"} onPress={() => setSubTab("calendar")} />
        <Chip label="Ausdauer" active={subTab === "endurance"} onPress={() => setSubTab("endurance")} />
      </View>
    </View>
    {subTab === "calendar" ? <CalendarScreen {...calendarProps} /> : <EnduranceScreen {...enduranceProps} />}
  </View>);
}


/** =========================
 * App
 * ========================= */
export default function App() {
  const t = STR[LANG];
  const [hydrated, setHydrated] = useState(false);
  const [tab, setTab] = useState("today");
  const [note, setNote] = useState("");
  const [logs, setLogs] = useState([]);
  const [prefs, setPrefs] = useState(DEFAULT_PREFS);
  const [userExercises, setUserExercises] = useState([]);
  const allExercises = useMemo(() => [...BASE_EXERCISES, ...userExercises], [userExercises]);
  const [plans, setPlans] = useState(DEFAULT_PLANS);
  const [activePlanId, setActivePlanId] = useState(null);
  const [calendarEntries, setCalendarEntries] = useState([]);
  const [calendarTemplates, setCalendarTemplates] = useState(DEFAULT_CALENDAR_TEMPLATES);
  const [calendarWeekOffset, setCalendarWeekOffset] = useState(0);
  const [sessions, setSessions] = useState([]);
  const [workout, setWorkout] = useState(null);
  const [enduranceTemplates, setEnduranceTemplates] = useState(DEFAULT_ENDURANCE_TEMPLATES);
  const [enduranceSessions, setEnduranceSessions] = useState([]);
  const [enduranceWorkout, setEnduranceWorkout] = useState(null);
  const [enduranceDetailOpen, setEnduranceDetailOpen] = useState(false);
  const [selectedEnduranceSession, setSelectedEnduranceSession] = useState(null);
  const [quickEnduranceOpen, setQuickEnduranceOpen] = useState(false);
  const [quickEnduranceEntry, setQuickEnduranceEntry] = useState(null);
  const [quickDurationMin, setQuickDurationMin] = useState("45");
  const [quickDistanceKm, setQuickDistanceKm] = useState("");
  const [quickRpe, setQuickRpe] = useState("");
  const [sessionModalOpen, setSessionModalOpen] = useState(false);
  const [selectedSession, setSelectedSession] = useState(null);
  const [editLogOpen, setEditLogOpen] = useState(false);
  const [selectedLog, setSelectedLog] = useState(null);
  const [exerciseDetailOpen, setExerciseDetailOpen] = useState(false);
  const [selectedExercise, setSelectedExercise] = useState(null);
  const [createExerciseOpen, setCreateExerciseOpen] = useState(false);
  const [importExercisesOpen, setImportExercisesOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [importDataOpen, setImportDataOpen] = useState(false);
  const [packInstalling, setPackInstalling] = useState(false);
  const [packStatusText, setPackStatusText] = useState("");
  const [user, setUser] = useState(null);
  const [groupModalOpen, setGroupModalOpen] = useState(false);
  const [myGroups, setMyGroups] = useState([]);
  const [activeGroupId, setActiveGroupId] = useState(null);
  const [sharedPlans, setSharedPlans] = useState([]);
  const [groupMembers, setGroupMembers] = useState([]);
  const [sharedPlanOpen, setSharedPlanOpen] = useState(null);
  const [sharedPlanSaving, setSharedPlanSaving] = useState(false);
  const [remoteUpdateFlag, setRemoteUpdateFlag] = useState(false);
  const [toast, setToast] = useState({ text: "", type: "info" });
  const [celebrateDone, setCelebrateDone] = useState(false);

  function addLog(type, overrideNote) { const entry = { id: uid(), type, note: (overrideNote ?? note).trim() ? (overrideNote ?? note).trim() : undefined, createdAt: Date.now() }; setLogs((prev) => [entry, ...prev]); setNote(""); }
  function showToast(text, type = "info") { setToast({ text, type }); setTimeout(() => setToast({ text: "", type: "info" }), 1800); }

  /** Persist load */
  useEffect(() => { (async () => { try { const raw = await AsyncStorage.getItem(STORAGE_KEY); if (!raw) { setHydrated(true); return; } const parsed = JSON.parse(raw); if (!parsed || (parsed.v !== 3 && parsed.v !== 4 && parsed.v !== 5)) { setHydrated(true); return; }
    if (Array.isArray(parsed.logs)) setLogs(parsed.logs);
    if (Array.isArray(parsed.plans)) { var OLD_V4_IDS = {"plan_gym_a":1,"plan_gym_b":1,"plan_gym_c":1,"p1":1}; var cleaned = parsed.plans.filter(function(p){return !OLD_V4_IDS[p.id]}); var savedIds = new Set(cleaned.map(function(p){return p.id})); var missing = DEFAULT_PLANS.filter(function(p){return !savedIds.has(p.id)}); setPlans(missing.length ? [...cleaned, ...missing] : cleaned); }
    if (Array.isArray(parsed.sessions)) setSessions(parsed.sessions.map(normalizeGymSession));
    if (Array.isArray(parsed.calendarEntries)) setCalendarEntries(parsed.calendarEntries.map(normalizeCalendarEntry));
    if (Array.isArray(parsed.calendarTemplates)) { var OLD_CT_IDS = {"ctpl_mo_recovery":1,"ctpl_di_gyma":1,"ctpl_mi_quality":1,"ctpl_do_volleyball":1,"ctpl_fr_gymb":1,"ctpl_sa_long":1,"ctpl_sa_gymc":1,"ctpl_so_rest":1}; var cleanedCt = parsed.calendarTemplates.filter(function(x){return !OLD_CT_IDS[x.id]}); var savedCtIds = new Set(cleanedCt.map(function(x){return x.id})); var missingCt = DEFAULT_CALENDAR_TEMPLATES.filter(function(x){return !savedCtIds.has(x.id)}); setCalendarTemplates(missingCt.length ? [...cleanedCt.map(normalizeCalendarTemplate), ...missingCt] : cleanedCt.map(normalizeCalendarTemplate)); }
    if (Array.isArray(parsed.enduranceTemplates)) { var OLD_ET_IDS = {"endtpl_recovery_run":1,"endtpl_quality_run":1,"endtpl_long_run":1,"endtpl_vo2max_rower":1}; var cleanedEt = parsed.enduranceTemplates.filter(function(x){return !OLD_ET_IDS[x.id]}); var savedEtIds = new Set(cleanedEt.map(function(x){return x.id})); var missingEt = DEFAULT_ENDURANCE_TEMPLATES.filter(function(x){return !savedEtIds.has(x.id)}); setEnduranceTemplates(missingEt.length ? [...cleanedEt, ...missingEt] : cleanedEt); }
    if (Array.isArray(parsed.enduranceSessions)) setEnduranceSessions(parsed.enduranceSessions);
    if (parsed.prefs) setPrefs(normalizePrefs(parsed.prefs));
    if (Array.isArray(parsed.userExercises)) setUserExercises(parsed.userExercises);
    if (typeof parsed.activeGroupId === "string" || parsed.activeGroupId === null) setActiveGroupId(parsed.activeGroupId || null);
    if (parsed.workout && parsed.workout.planId && parsed.workout.sets) setWorkout(parsed.workout);
  } catch (e) { /* ignore */ } finally { setHydrated(true); } })(); }, []);

  useEffect(() => { if (!supabase) return undefined; let mounted = true; supabase.auth.getUser().then(({ data }) => { if (mounted) setUser(data?.user || null); }); const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => { setUser(session?.user || null); }); return () => { mounted = false; subscription?.unsubscribe(); }; }, []);

  /** Persist save */
  const saveTimerRef = useRef(null);
  useEffect(() => { if (!hydrated) return; if (saveTimerRef.current) clearTimeout(saveTimerRef.current); saveTimerRef.current = setTimeout(async () => { try { await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ v: 5, logs, plans, sessions, calendarEntries, calendarTemplates, enduranceTemplates, enduranceSessions, userExercises, prefs, activeGroupId, workout: workout || null })); } catch (e) { /* ignore */ } }, 400); return () => { if (saveTimerRef.current) clearTimeout(saveTimerRef.current); }; }, [hydrated, logs, plans, sessions, calendarEntries, calendarTemplates, enduranceTemplates, enduranceSessions, userExercises, prefs, activeGroupId, workout]);

  /** Exercise actions */
  function addCustomExercise(ex) { setUserExercises((prev) => [ex, ...prev]); }
  function deleteUserExercise(exId) { setUserExercises((prev) => prev.filter((e) => e.id !== exId)); }
  function importExercises(list) { const existingKeys = new Set(allExercises.map(normalizeKey)); let added = 0, skipped = 0; const toAdd = []; for (const ex of list) { const key = normalizeKey(ex); if (!key || key.startsWith("__") || existingKeys.has(key)) { skipped++; continue; } existingKeys.add(key); toAdd.push({ id: ex.id || `ix_${uid()}`, name: ex.name, category: ex.category || "Other", muscle: ex.muscle || "Other", source: ex.source || "import", meta: ex.meta, howto: ex.howto, defaults: ex.defaults, setup: ex.setup }); added++; } if (toAdd.length > 0) setUserExercises((prev) => [...toAdd, ...prev]); return { added, skipped }; }
  async function installFreeExerciseDbPack() { try { setPackInstalling(true); setPackStatusText("Downloading..."); const res = await fetch(FREE_EXERCISE_DB_URL); if (!res.ok) throw new Error(`HTTP ${res.status}`); setPackStatusText("Parsing..."); const arr = await res.json(); if (!Array.isArray(arr)) throw new Error("Not an array."); setPackStatusText(`Mapping ${arr.length}...`); const mapped = arr.map((raw) => ({ id: `fedb_${String(raw?.id || raw?.name || uid())}`, name: String(raw?.name || "").trim() || "Exercise", category: mapEquipmentToCategory(raw?.equipment), muscle: mapPrimaryMuscleToGroup(raw?.primaryMuscles), source: "pack:free-exercise-db", meta: { equipment: raw?.equipment ?? "", primaryMuscles: raw?.primaryMuscles ?? [], categoryType: raw?.category ?? "" } })); setPackStatusText("Importing..."); const result = importExercises(mapped); setPackStatusText(`Done. +${result.added} / skipped ${result.skipped}`); } catch (e) { setPackStatusText(`Error: ${String(e?.message || e)}`); } finally { setPackInstalling(false); } }

  /** Group functions (unchanged from original) */
  async function refreshMyGroups() { if (!supabase || !user) { setMyGroups([]); setActiveGroupId(null); return; } const { data, error } = await supabase.from("group_members").select("role, groups:group_id (id, name, code)").eq("user_id", user.id); if (error) return; const groups = (data || []).map((x) => ({ ...(x.groups || {}), role: x.role })).filter((g) => g.id); setMyGroups(groups); if (!activeGroupId && groups[0]) { setActiveGroupId(groups[0].id); refreshSharedPlans(groups[0].id); } }
  async function refreshSharedPlans(groupId) { if (!supabase || !user || !groupId) return; const { data, error } = await supabase.from("shared_plans").select("id, group_id, plan_key, plan_name, plan, updated_at, updated_by, version").eq("group_id", groupId).order("updated_at", { ascending: false }); if (error) { showToast("Online required", "error"); return; } setSharedPlans(data || []); }
  async function fetchGroupMembers(groupId) { if (!supabase || !user || !groupId) return; const { data } = await supabase.from("group_members").select("user_id, role").eq("group_id", groupId).order("created_at", { ascending: true }); setGroupMembers(data || []); }
  async function updateMemberRole(memberUserId, role) { if (!supabase || !activeGroupId) return; await supabase.from("group_members").update({ role }).eq("group_id", activeGroupId).eq("user_id", memberUserId); fetchGroupMembers(activeGroupId); refreshMyGroups(); }
  async function removeGroupMember(memberUserId) { if (!supabase || !activeGroupId) return; await supabase.from("group_members").delete().eq("group_id", activeGroupId).eq("user_id", memberUserId); fetchGroupMembers(activeGroupId); refreshMyGroups(); }
  async function regenerateGroupCode() { if (!supabase || !activeGroupId) return; await supabase.from("groups").update({ code: makeJoinCode(8) }).eq("id", activeGroupId); refreshMyGroups(); }
  function openSharedPlanLive(row) { setSharedPlanOpen(row); setRemoteUpdateFlag(false); }
  async function reloadSharedPlan() { if (!supabase || !sharedPlanOpen?.id) return; const { data } = await supabase.from("shared_plans").select("id, group_id, plan_key, plan_name, plan, updated_at, updated_by, version").eq("id", sharedPlanOpen.id).single(); if (data) { setSharedPlanOpen(data); setRemoteUpdateFlag(false); } }
  async function saveSharedPlanLive(planPatch) { if (!supabase || !user || !sharedPlanOpen) return; try { setSharedPlanSaving(true); const { data, error } = await supabase.from("shared_plans").upsert({ group_id: sharedPlanOpen.group_id || activeGroupId, plan_key: sharedPlanOpen.plan_key, plan_name: planPatch.name || sharedPlanOpen.plan_name, plan: planPatch, updated_by: user.id, updated_at: new Date().toISOString(), version: (sharedPlanOpen.version || 1) + 1 }, { onConflict: "group_id,plan_key" }).select("id, group_id, plan_key, plan_name, plan, updated_at, updated_by, version").single(); if (error) { showToast("Save failed", "error"); return; } if (data) setSharedPlanOpen(data); showToast("Saved", "success"); setRemoteUpdateFlag(false); refreshSharedPlans(activeGroupId); } finally { setSharedPlanSaving(false); } }
  async function createGroup(name) { if (!supabase || !user) return; const n = String(name || "").trim(); if (!n) return; let code = makeJoinCode(8); for (let attempt = 0; attempt < 2; attempt++) { const { data: g, error } = await supabase.from("groups").insert({ name: n, code, created_by: user.id }).select("id, name, code").single(); if (error) { code = makeJoinCode(8); continue; } await supabase.from("group_members").insert({ group_id: g.id, user_id: user.id, role: "owner" }); await refreshMyGroups(); setActiveGroupId(g.id); await refreshSharedPlans(g.id); return; } }
  async function joinByCode(code) { if (!supabase || !user) return; const c = String(code || "").trim().toUpperCase(); if (!c) return; const { data: g, error } = await supabase.from("groups").select("id, name, code").eq("code", c).single(); if (error || !g) return; await supabase.from("group_members").insert({ group_id: g.id, user_id: user.id, role: "member" }); await refreshMyGroups(); setActiveGroupId(g.id); await refreshSharedPlans(g.id); }
  async function leaveGroup(groupId) { if (!supabase || !user) return; await supabase.from("group_members").delete().eq("group_id", groupId).eq("user_id", user.id); if (activeGroupId === groupId) { setActiveGroupId(null); setSharedPlans([]); } await refreshMyGroups(); }
  async function publishPlanToGroup(plan) { if (!supabase || !user || !activeGroupId || !plan) return; await supabase.from("shared_plans").upsert({ group_id: activeGroupId, plan_key: `${user.id}_${plan.id}`, plan_name: plan.name || "Plan", plan, updated_by: user.id, updated_at: new Date().toISOString() }, { onConflict: "group_id,plan_key" }); await refreshSharedPlans(activeGroupId); }
  function importSharedPlanToLocal(row) { const p = row?.plan; if (!p) return; setPlans((prev) => [{ ...p, id: uid(), name: `${row.plan_name} (Shared)` }, ...prev]); }

  useEffect(() => { if (!activeGroupId) return; fetchGroupMembers(activeGroupId); refreshSharedPlans(activeGroupId); }, [activeGroupId]);
  useEffect(() => { if (!supabase || !activeGroupId) return undefined; const ch = supabase.channel(`shared_plans_${activeGroupId}`).on("postgres_changes", { event: "*", schema: "public", table: "shared_plans", filter: `group_id=eq.${activeGroupId}` }, (payload) => { refreshSharedPlans(activeGroupId); const changedId = payload?.new?.id || payload?.old?.id; const changedBy = payload?.new?.updated_by; if (sharedPlanOpen?.id && changedId === sharedPlanOpen.id && changedBy && changedBy !== user?.id) setRemoteUpdateFlag(true); }).subscribe(); return () => { supabase.removeChannel(ch); }; }, [supabase, activeGroupId, sharedPlanOpen?.id, user?.id]);
  useEffect(() => { if (!user?.id) return; refreshMyGroups(); }, [user?.id]);

  /** Export/Import */
  const exportPayload = useMemo(() => ({ v: 5, logs, plans, sessions, calendarEntries, calendarTemplates, enduranceTemplates, enduranceSessions, userExercises, prefs, activeGroupId }), [logs, plans, sessions, calendarEntries, calendarTemplates, enduranceTemplates, enduranceSessions, userExercises, prefs, activeGroupId]);
  function importAppData(obj) { if (!obj || typeof obj !== "object") return { ok: false, error: "JSON muss ein Objekt sein." }; if (obj.v !== 3 && obj.v !== 4 && obj.v !== 5) return { ok: false, error: "Version passt nicht." }; if (!Array.isArray(obj.logs) || !Array.isArray(obj.plans) || !Array.isArray(obj.sessions) || !Array.isArray(obj.calendarEntries) || !Array.isArray(obj.userExercises)) return { ok: false, error: "Struktur unvollständig." }; setLogs(obj.logs); setPlans(obj.plans); setSessions(obj.sessions.map(normalizeGymSession)); setCalendarEntries(obj.calendarEntries.map(normalizeCalendarEntry)); setCalendarTemplates(Array.isArray(obj.calendarTemplates) ? obj.calendarTemplates.map(normalizeCalendarTemplate) : []); setEnduranceTemplates(Array.isArray(obj.enduranceTemplates) ? obj.enduranceTemplates : []); setEnduranceSessions(Array.isArray(obj.enduranceSessions) ? obj.enduranceSessions : []); setUserExercises(obj.userExercises); setPrefs(normalizePrefs(obj.prefs)); setActiveGroupId(typeof obj.activeGroupId === "string" ? obj.activeGroupId : null); setTab("today"); setActivePlanId(null); return { ok: true }; }

  /** Workout start/finish */
  function onStartWorkout(plan) {
    if (!plan || plan.items.length === 0) return;
    const lastByExercise = {};
    if (prefs.autoFillFromLastSession) { for (const sess of sessions) { for (const it of sess.items || []) { if (!lastByExercise[it.exerciseId]) lastByExercise[it.exerciseId] = it; } } }
    const sets = {};
    plan.items.forEach((it) => { const ex = allExercises.find(function(e){return e.id===it.exerciseId}); var iType = ex?.inputType || "kg_reps"; const lastItem = lastByExercise[it.exerciseId]; sets[it.id] = it.sets.map((st, idx) => { const lastSet = lastItem?.performed?.[idx] || {}; var base = { done: false, note: "", missing: false, targetRepMin: String(st.targetRepMin || prefs.defaultRepRange.min || ""), targetRepMax: String(st.targetRepMax || st.targetReps || prefs.defaultRepRange.max || "") };
      if (iType === "kg_reps") { base.kg = prefs.autoFillFromLastSession ? String(lastSet.kg || st.targetKg || "") : String(st.targetKg || ""); base.reps = prefs.autoFillFromLastSession ? String(lastSet.reps || "") : ""; }
      else if (iType === "kg_dist") { base.kg = prefs.autoFillFromLastSession ? String(lastSet.kg || st.targetKg || "") : String(st.targetKg || ""); base.dist = ""; }
      else if (iType === "reps") { base.reps = ""; base.kg = ""; }
      else if (iType === "duration" || iType === "time_sec") { base.duration = ""; base.kg = ""; base.reps = ""; }
      else if (iType === "dist") { base.dist = ""; base.kg = ""; base.reps = ""; }
      else if (iType === "check") { base.kg = ""; base.reps = ""; }
      else { base.kg = String(st.targetKg || ""); base.reps = ""; }
      return base; }); });
    setWorkout({ id: uid(), planId: plan.id, startedAt: Date.now(), sets, restStartedAt: null, restDurationSec: 0, suggestions: {} });
  }

  function finishWorkout() {
    if (!workout) return;
    const plan = plans.find((p) => p.id === workout.planId);
    if (!plan) { setWorkout(null); return; }
    const endedAt = Date.now(); const durationMin = minutesBetween(workout.startedAt, endedAt);
    let totalSets = 0, doneSets = 0, totalVolumeKg = 0, totalReps = 0, prWeight = 0, prVolume = 0;
    const exerciseNow = {};
    const items = plan.items.map((it) => {
      const ex = allExercises.find((e) => e.id === it.exerciseId) || { id: it.exerciseId, name: "Exercise", category: "", muscle: "", source: "unknown" };
      const performed = workout.sets[it.id] || [];
      totalSets += performed.length; doneSets += performed.filter((s2) => s2.done).length;
      performed.forEach((s2) => { if (!s2.done) return; const kg = toNum(s2.kg); const reps = toNum(s2.reps); const vol = kg * reps; totalVolumeKg += vol; totalReps += reps; prWeight = Math.max(prWeight, kg); prVolume = Math.max(prVolume, vol); const prev = exerciseNow[ex.id] || { name: ex.name, maxKg: 0, volume: 0 }; prev.maxKg = Math.max(prev.maxKg, kg); prev.volume += vol; exerciseNow[ex.id] = prev; });
      return { itemId: it.id, exerciseId: ex.id, name: ex.name, category: ex.category, muscle: ex.muscle, progressionMode: it.progressionMode || "double", incrementKg: it.incrementKg, exerciseNote: workout.exerciseNotes?.[it.id] || "", performed };
    });
    const prevByExercise = {}; for (const sPrev of sessions) { for (const itPrev of sPrev.items || []) { if (!prevByExercise[itPrev.exerciseId]) prevByExercise[itPrev.exerciseId] = Math.max(0, ...(itPrev.performed || []).map((x) => toNum(x.kg))); } }
    const exerciseTrends = Object.entries(exerciseNow).map(([exerciseId, data]) => ({ exerciseId, name: data.name, maxKg: data.maxKg, prevMaxKg: prevByExercise[exerciseId] || 0, deltaKg: data.maxKg - (prevByExercise[exerciseId] || 0), volume: data.volume }));
    const withMissing = items.map((it) => ({ ...it, performed: (it.performed || []).map((s) => ({ ...s, note: s.note || "", missing: String(s.kg || "").trim() === "" || String(s.reps || "").trim() === "" })) }));
    setSessions((prev) => [{ id: uid(), type: "Gym", planId: plan.id, planName: plan.name, startedAt: workout.startedAt, endedAt, durationMin, totalSets, doneSets, totalVolumeKg: Number(totalVolumeKg.toFixed(1)), totalReps, prWeight, prVolume: Number(prVolume.toFixed(1)), exerciseTrends, status: isSessionComplete(withMissing) ? "complete" : "incomplete", items: withMissing }, ...prev]);
    addLog("Gym", `Workout: ${plan.name}\nSets: ${doneSets}/${totalSets}\nDauer: ~${durationMin} min`);
    setWorkout(null); setCelebrateDone(true); setTimeout(() => setCelebrateDone(false), 800);
  }

  function openSession(session) { setSelectedSession(session); setSessionModalOpen(true); }
  function openLog(log) { setSelectedLog(log); setEditLogOpen(true); }
  function saveLog(nextLog) { setLogs((prev) => prev.map((l) => (l.id === nextLog.id ? { ...l, ...nextLog } : l))); setEditLogOpen(false); }
  function deleteLog(logId) { setLogs((prev) => prev.filter((l) => l.id !== logId)); setEditLogOpen(false); }
  function openExerciseDetail(exercise) { setSelectedExercise(exercise); setExerciseDetailOpen(true); }
  function saveExerciseDefaults(exercise, defaultsPatch, setupPatch) { if (!exercise) return; if (setupPatch) { if (exercise.source === "base") { setPrefs((prev) => ({ ...prev, exerciseSetupOverrides: { ...(prev.exerciseSetupOverrides || {}), [exercise.id]: { ...(prev.exerciseSetupOverrides?.[exercise.id] || {}), ...setupPatch } } })); } else { setUserExercises((prev) => prev.map((ex) => (ex.id === exercise.id ? { ...ex, setup: { ...(ex.setup || {}), ...setupPatch } } : ex))); } } if (!defaultsPatch) return; if (exercise.source === "base") { setPrefs((prev) => ({ ...prev, exerciseDefaultsOverrides: { ...(prev.exerciseDefaultsOverrides || {}), [exercise.id]: { ...(prev.exerciseDefaultsOverrides?.[exercise.id] || {}), ...defaultsPatch } } })); return; } setUserExercises((prev) => prev.map((ex) => (ex.id === exercise.id ? { ...ex, defaults: { ...(ex.defaults || {}), ...defaultsPatch } } : ex))); }
  function saveSessionEdits(updatedSession) { const normalized = normalizeGymSession(updatedSession); const doneSets = (normalized.items || []).reduce((acc, it) => acc + (it.performed || []).filter((s) => s.done).length, 0); const totalSets = (normalized.items || []).reduce((acc, it) => acc + (it.performed || []).length, 0); const merged = { ...normalized, doneSets, totalSets }; setSessions((prev) => prev.map((s) => (s.id === merged.id ? merged : s))); setSelectedSession((prev) => (prev?.id === merged.id ? merged : prev)); }

  const todayKey = formatDateKey(new Date());
  const todayAgenda = useMemo(() => calendarEntries.filter((e) => e.date === todayKey).sort((a, b) => parseTimeToMin(a.startTime) - parseTimeToMin(b.startTime)), [calendarEntries, todayKey]);

  function markAgendaDone(entry) { if (!entry) return; if (["Run","Bike","Swim"].includes(entry.sportType)) { openQuickEnduranceFinish(entry); return; } setCalendarEntries((prev) => prev.map((e) => (e.id === entry.id ? { ...e, status: "done", updatedAt: Date.now() } : e))); addLog(entry.sportType || "Other", `${entry.title} ${entry.durationMin || 0}min`); }
  function startAgendaGym(entry) { if (!entry?.planId) return; const plan = plans.find((p) => p.id === entry.planId); if (!plan) return; onStartWorkout(plan); }
  function moveAgendaToTomorrow(entryId) { setCalendarEntries((prev) => prev.map((e) => { if (e.id !== entryId) return e; const d = parseDateKey(e.date); if (!d) return e; return { ...e, date: formatDateKey(addDays(d, 1)), status: e.status === "done" ? "planned" : e.status, updatedAt: Date.now() }; })); }
  function copyAgendaToNextWeek(entryId) { setCalendarEntries((prev) => { const src = prev.find((e) => e.id === entryId); if (!src) return prev; const d = parseDateKey(src.date); if (!d) return prev; const targetDate = formatDateKey(addDays(d, 7)); const exists = prev.some((e) => e.date === targetDate && e.title === src.title && e.startTime === src.startTime); if (exists) return prev; const now = Date.now(); return [{ ...src, id: uid(), date: targetDate, status: "planned", createdAt: now, updatedAt: now }, ...prev]; }); }
  function applyTemplatesToWeek(weekStartDate) { const start = new Date(weekStartDate.getFullYear(), weekStartDate.getMonth(), weekStartDate.getDate()); setCalendarEntries((prev) => { const next = [...prev]; const now = Date.now(); for (const tpl of calendarTemplates) { if (!tpl?.active) continue; const wd = Math.min(7, Math.max(1, Number(tpl.weekday) || 1)); const date = formatDateKey(addDays(start, wd - 1)); const existingIdx = next.findIndex((e) => e.date === date && e.templateId === tpl.id && e.startTime === (tpl.startTime || "07:00")); const mapped = { id: existingIdx >= 0 ? next[existingIdx].id : uid(), date, startTime: tpl.startTime || "07:00", durationMin: Math.max(1, parseInt(String(tpl.durationMin || 45), 10) || 45), title: tpl.title || "Template", sportType: tpl.sportType || "Other", planId: tpl.sportType === "Gym" ? tpl.planId || null : null, status: existingIdx >= 0 ? next[existingIdx].status : "planned", templateId: tpl.id, createdAt: existingIdx >= 0 ? next[existingIdx].createdAt : now, updatedAt: now }; if (existingIdx >= 0) next[existingIdx] = { ...next[existingIdx], ...mapped }; else next.unshift(mapped); } return next; }); }

  /** Endurance actions */
  function saveEnduranceTemplate(tpl) { setEnduranceTemplates((prev) => { const idx = prev.findIndex((x) => x.id === tpl.id); if (idx >= 0) { const next = [...prev]; next[idx] = { ...next[idx], ...tpl, updatedAt: Date.now() }; return next; } return [{ ...tpl, createdAt: tpl.createdAt || Date.now(), updatedAt: Date.now() }, ...prev]; }); }
  function deleteEnduranceTemplate(id) { setEnduranceTemplates((prev) => prev.filter((x) => x.id !== id)); }
  function scheduleEnduranceTemplate(template, date, time) { if (!parseDateKey(date)) return; const now = Date.now(); setCalendarEntries((prev) => { const exists = prev.some((e) => e.date === date && e.templateId === template.id && e.startTime === time); if (exists) return prev; return [normalizeCalendarEntry({ id: uid(), date, startTime: time || "07:00", durationMin: template?.target?.durationMin || 45, title: template?.name || "Endurance", sportType: template?.sportType || "Other", status: "planned", templateId: template.id, createdAt: now, updatedAt: now }), ...prev]; }); }
  function startEnduranceFromTemplate(template, plannedFromCalendarId = null) { if (!template) return; const mode = Array.isArray(template.intervals) && template.intervals.length ? "intervals" : "simple"; setEnduranceWorkout({ id: uid(), sportType: template.sportType, workoutType: template.workoutType, title: template.name, templateId: template.id, plannedFromCalendarId, mode, running: false, elapsedSec: 0, intervals: template.intervals || [], intervalsPerformed: (template.intervals || []).map((x) => ({ id: x.id || uid(), kind: x.kind, plannedDurationSec: x.durationSec, actualDurationSec: 0, done: false })), currentIndex: 0, currentRemainingSec: (template.intervals || [])[0]?.durationSec || 0, target: template.target || {}, notes: template.notes || "" }); }
  function startEnduranceFromAgenda(entry) { const tpl = enduranceTemplates.find((x) => x.id === entry.templateId); if (tpl) { startEnduranceFromTemplate(tpl, entry.id); return; } startEnduranceFromTemplate({ id: null, name: entry.title, sportType: entry.sportType, workoutType: "Other", target: { durationMin: entry.durationMin }, intervals: [], notes: "" }, entry.id); }
  function openQuickEnduranceFinish(entry) { setQuickEnduranceEntry(entry); setQuickDurationMin(String(entry?.durationMin || 45)); setQuickDistanceKm(""); setQuickRpe(""); setQuickEnduranceOpen(true); }
  function saveEnduranceSessionAndMark(entry, actual, intervalsPerformed) { const now = Date.now(); setEnduranceSessions((prev) => [{ id: uid(), sportType: entry.sportType, workoutType: entry.workoutType || "Other", title: entry.title, date: entry.date || formatDateKey(new Date()), templateId: entry.templateId || null, actual, intervalsPerformed, createdAt: now, updatedAt: now }, ...prev]); setCalendarEntries((prev) => prev.map((e) => (e.id === entry.id ? { ...e, status: "done", updatedAt: now } : e))); addLog(entry.sportType || "Other", `${entry.title} - ${actual.durationMin || "-"}min - ${actual.distanceKm || "-"}km`); }
  function finishQuickEndurance() { if (!quickEnduranceEntry) return; saveEnduranceSessionAndMark(quickEnduranceEntry, { durationMin: Math.max(1, parseInt(quickDurationMin || "1", 10) || 1), distanceKm: quickDistanceKm ? Number(quickDistanceKm.replace(",", ".")) : undefined, rpe: quickRpe ? Number(quickRpe) : undefined }); setQuickEnduranceOpen(false); setQuickEnduranceEntry(null); }
  function finishEnduranceWorkout(payload) { if (!payload) return; saveEnduranceSessionAndMark({ id: payload.plannedFromCalendarId || null, sportType: payload.sportType, workoutType: payload.workoutType, title: payload.title, date: formatDateKey(new Date()), templateId: payload.templateId || null }, { durationMin: Math.max(1, Math.round((payload.elapsedSec || 0) / 60) || payload.target?.durationMin || 1), distanceKm: payload.target?.distanceKm }, payload.intervalsPerformed); setEnduranceWorkout(null); }
  function openEnduranceSession(session) { setSelectedEnduranceSession(session); setEnduranceDetailOpen(true); }

  /** Workout screen priority */
  if (enduranceWorkout) return <EnduranceWorkoutScreen workout={enduranceWorkout} setWorkout={setEnduranceWorkout} onFinish={finishEnduranceWorkout} />;
  if (workout) { const plan = plans.find((p) => p.id === workout.planId); if (!plan) return null; return (<SafeAreaView style={styles.root}><WorkoutScreen t={t} plan={plan} workout={workout} setWorkout={setWorkout} onFinish={finishWorkout} allExercises={allExercises} onOpenExerciseDetail={openExerciseDetail} sessions={sessions} /></SafeAreaView>); }

  const activeGroup = myGroups.find((g) => g.id === activeGroupId) || null;
  const myRole = activeGroup?.role || "member";

  return (
    <SafeAreaView style={styles.root}>
      {tab === "today" ? <TodayScreen t={t} note={note} setNote={setNote} logs={logs} addLog={addLog} sessions={sessions} onOpenSession={openSession} todayAgenda={todayAgenda} onDoneAgenda={markAgendaDone} onStartAgendaGym={startAgendaGym} onStartAgendaEndurance={startEnduranceFromAgenda} onMoveAgendaTomorrow={moveAgendaToTomorrow} onCopyAgendaNextWeek={copyAgendaToNextWeek} onOpenLog={openLog} /> : null}
      {tab === "plans" ? <PlansScreen t={t} plans={plans} setPlans={setPlans} activePlanId={activePlanId} setActivePlanId={setActivePlanId} onStartWorkout={onStartWorkout} allExercises={allExercises} activeGroup={activeGroup} onOpenGroups={() => setGroupModalOpen(true)} onSharePlan={publishPlanToGroup} sharedPlans={sharedPlans} onOpenSharedLive={openSharedPlanLive} onImportSharedPlan={importSharedPlanToLocal} myRole={myRole} sharedPlanOpen={sharedPlanOpen} onCloseSharedPlan={() => setSharedPlanOpen(null)} onSaveSharedPlan={saveSharedPlanLive} sharedPlanSaving={sharedPlanSaving} remoteUpdateFlag={remoteUpdateFlag} onReloadSharedPlan={reloadSharedPlan} /> : null}
      {tab === "library" ? <LibraryScreen t={t} allExercises={allExercises} userExercises={userExercises} onDeleteUserExercise={deleteUserExercise} onOpenCreate={() => setCreateExerciseOpen(true)} onOpenImportExercises={() => setImportExercisesOpen(true)} onOpenExport={() => setExportOpen(true)} onOpenImportData={() => setImportDataOpen(true)} packInstalling={packInstalling} packStatusText={packStatusText} onInstallPack={installFreeExerciseDbPack} prefs={prefs} setPrefs={setPrefs} onOpenExerciseDetail={openExerciseDetail} /> : null}
      {tab === "progress" ? <ProgressScreen sessions={sessions} logs={logs} calendarEntries={calendarEntries} allExercises={allExercises} prefs={prefs} setPrefs={setPrefs} /> : null}
      {tab === "planner" ? <PlannerScreen
        calendarProps={{ t, plans, calendarEntries, setCalendarEntries, calendarTemplates, setCalendarTemplates, calendarWeekOffset, setCalendarWeekOffset, onApplyTemplatesToWeek: applyTemplatesToWeek }}
        enduranceProps={{ templates: enduranceTemplates, sessions: enduranceSessions, plans, onSaveTemplate: saveEnduranceTemplate, onDeleteTemplate: deleteEnduranceTemplate, onStartTemplate: startEnduranceFromTemplate, onScheduleTemplate: scheduleEnduranceTemplate, onOpenSession: openEnduranceSession }}
      /> : null}

      {/* ===== REDESIGNED TAB BAR ===== */}
      <View style={styles.tabBar}>
        <TabIcon label={t.tabs.today} active={tab === "today"} onPress={() => setTab("today")} />
        <TabIcon label={t.tabs.plans} active={tab === "plans"} onPress={() => setTab("plans")} />
        <TabIcon label={t.tabs.library} active={tab === "library"} onPress={() => setTab("library")} />
        <TabIcon label={t.tabs.progress} active={tab === "progress"} onPress={() => setTab("progress")} />
        <TabIcon label={t.tabs.planner} active={tab === "planner"} onPress={() => setTab("planner")} />
      </View>

      {/* Modals */}
      <WorkoutDetailModal visible={sessionModalOpen} onClose={() => setSessionModalOpen(false)} t={t} session={selectedSession} onSaveSession={saveSessionEdits} />
      <EditLogModal visible={editLogOpen} onClose={() => setEditLogOpen(false)} log={selectedLog} onSave={saveLog} onDelete={deleteLog} />
      <ExerciseDetailModal visible={exerciseDetailOpen} onClose={() => setExerciseDetailOpen(false)} exercise={selectedExercise} prefs={prefs} setPrefs={setPrefs} onSaveExerciseDefaults={saveExerciseDefaults} />
      <CreateExerciseModal visible={createExerciseOpen} onClose={() => setCreateExerciseOpen(false)} t={t} onSave={addCustomExercise} />
      <ImportExercisesModal visible={importExercisesOpen} onClose={() => setImportExercisesOpen(false)} t={t} onImport={importExercises} />
      <ExportDataModal visible={exportOpen} onClose={() => setExportOpen(false)} t={t} data={exportPayload} />
      <ImportDataModal visible={importDataOpen} onClose={() => setImportDataOpen(false)} t={t} onImport={importAppData} />
      <EnduranceSessionDetailModal visible={enduranceDetailOpen} onClose={() => setEnduranceDetailOpen(false)} session={selectedEnduranceSession} />
      <Modal visible={quickEnduranceOpen} animationType="slide" onRequestClose={() => setQuickEnduranceOpen(false)}><SafeAreaView style={styles.modalRoot}><View style={styles.modalHeader}><Text style={styles.modalTitle}>Finish Endurance</Text><PillButton label={t.today.close} onPress={() => setQuickEnduranceOpen(false)} variant="secondary" /></View><ScrollView contentContainerStyle={styles.screenPad}><GlassCard title={quickEnduranceEntry?.title || "Session"}><View style={styles.setRow}><View style={{ flex: 1, marginRight: 10 }}><Text style={styles.smallLabel}>Duration (min)</Text><TextInput value={quickDurationMin} onChangeText={(v) => setQuickDurationMin(v.replace(/[^\d]/g, ""))} keyboardType="number-pad" style={styles.inputSmall} /></View><View style={{ flex: 1 }}><Text style={styles.smallLabel}>Distance (km)</Text><TextInput value={quickDistanceKm} onChangeText={(v) => setQuickDistanceKm(v.replace(/[^\d.]/g, ""))} keyboardType="decimal-pad" style={styles.inputSmall} /></View></View><Text style={styles.smallLabel}>RPE</Text><TextInput value={quickRpe} onChangeText={(v) => setQuickRpe(v.replace(/[^\d]/g, ""))} keyboardType="number-pad" style={styles.inputSmall} /><View style={styles.rowWrap}><PillButton label="Save" onPress={finishQuickEndurance} variant="primary" /></View></GlassCard></ScrollView></SafeAreaView></Modal>
      <ToastBanner toast={toast} />
      <CelebrationOverlay visible={celebrateDone} />
      <GroupModal visible={groupModalOpen} onClose={() => setGroupModalOpen(false)} t={t} user={user} myGroups={myGroups} activeGroupId={activeGroupId} setActiveGroupId={setActiveGroupId} sharedPlans={sharedPlans} onRefreshSharedPlans={refreshSharedPlans} onCreateGroup={createGroup} onJoinByCode={joinByCode} onLeaveGroup={leaveGroup} onImportSharedPlan={importSharedPlanToLocal} members={groupMembers} myRole={myRole} onRefreshMembers={fetchGroupMembers} onUpdateMemberRole={updateMemberRole} onRemoveMember={removeGroupMember} onRegenerateCode={regenerateGroupCode} />
    </SafeAreaView>
  );
}


/** =========================
 * Styles - Redesigned Tab Bar for iPhone
 * ========================= */
const TAB_BOTTOM = Platform.OS === "ios" ? 34 : 14;

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: DS.colors.bg },
  screenPad: { paddingHorizontal: DS.spacing.l, paddingTop: DS.spacing.m, paddingBottom: 160 },
  h1: { ...DS.typography.h1, color: DS.colors.text, marginBottom: DS.spacing.m, letterSpacing: 0.2 },

  card: { backgroundColor: DS.colors.surface, borderRadius: DS.radius.card, paddingHorizontal: DS.spacing.m, paddingVertical: DS.spacing.m, borderWidth: 1, borderColor: DS.colors.border, shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 14, shadowOffset: { width: 0, height: 7 }, marginBottom: DS.spacing.m },
  cardTitle: { fontSize: 15, fontWeight: "700", color: "#0B0B0F", marginBottom: 12, letterSpacing: 0.2 },

  label: { ...DS.typography.small, color: "#3A3A44", marginBottom: 8, marginTop: 8 },
  smallLabel: { fontSize: 11, fontWeight: "600", color: "#3A3A44", marginBottom: 6 },

  input: { backgroundColor: "rgba(255,255,255,0.9)", borderWidth: 1, borderColor: "rgba(0,0,0,0.08)", paddingHorizontal: 14, paddingVertical: 13, borderRadius: DS.radius.input, color: "#0B0B0F" },
  inputGlowWrap: { backgroundColor: "rgba(255,255,255,0.9)", borderWidth: 1, paddingHorizontal: 14, paddingVertical: 13, borderRadius: DS.radius.input },
  glowBlobBlue: { position: "absolute", left: 8, right: 8, top: 4, bottom: 4, backgroundColor: "rgba(68,142,255,0.08)", borderRadius: DS.radius.input },
  glowBlobGreen: { position: "absolute", left: 22, right: 22, top: 9, bottom: 9, backgroundColor: "rgba(47,204,141,0.06)", borderRadius: DS.radius.input },
  inputSmall: { backgroundColor: "rgba(255,255,255,0.9)", borderWidth: 1, borderColor: "rgba(0,0,0,0.08)", paddingHorizontal: 12, paddingVertical: 10, borderRadius: 14, color: "#0B0B0F" },

  help: { marginTop: 10, color: DS.colors.muted, fontSize: 12, lineHeight: 18 },
  muted: { color: DS.colors.muted, fontSize: 13, lineHeight: 20 },

  row: { flexDirection: "row", alignItems: "center", marginTop: 12 },
  rowWrap: { flexDirection: "row", flexWrap: "wrap", marginTop: 12 },
  rowBetween: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },

  statBox: { flex: 1, backgroundColor: "rgba(0,0,0,0.03)", borderRadius: DS.radius.input, padding: 12, borderWidth: 1, borderColor: "rgba(0,0,0,0.05)" },
  statLabel: { fontSize: 12, color: "#5C5C66", fontWeight: "600" },
  statValue: { fontSize: 22, fontWeight: "800", color: "#0B0B0F", marginTop: 4 },
  statValueSmall: { fontSize: 14, fontWeight: "700", color: "#0B0B0F", marginTop: 4 },
  timerBig: { fontSize: 28, fontWeight: "800", color: "#0B0B0F" },

  pill: { paddingVertical: 10, paddingHorizontal: 12, borderRadius: DS.radius.button, marginRight: 10, marginBottom: 10, borderWidth: 1 },
  pillPrimary: { backgroundColor: "#0B0B0F", borderColor: "#0B0B0F" },
  pillSecondary: { backgroundColor: "rgba(255,255,255,0.9)", borderColor: "rgba(0,0,0,0.12)" },
  pillTextPrimary: { color: "white", fontWeight: "700", fontSize: 13 },
  pillTextSecondary: { color: "#0B0B0F", fontWeight: "700", fontSize: 13 },

  listItem: { backgroundColor: "rgba(0,0,0,0.03)", borderRadius: DS.radius.input, padding: 12, borderWidth: 1, borderColor: "rgba(0,0,0,0.05)", marginBottom: 12 },
  listItemRow: { flexDirection: "row", alignItems: "center", backgroundColor: "rgba(0,0,0,0.03)", borderRadius: DS.radius.input, padding: 12, borderWidth: 1, borderColor: "rgba(0,0,0,0.05)", marginBottom: 12 },
  listTitle: { color: "#0B0B0F", fontWeight: "800", fontSize: 14 },
  listMeta: { color: "#5C5C66", marginTop: 4, fontSize: 12, fontWeight: "600" },
  listBody: { color: "#0B0B0F", marginTop: 8, fontSize: 13, lineHeight: 18 },
  badge: { color: "#5C5C66", fontSize: 12, fontWeight: "800" },
  incompleteBadge: { marginTop: 6, color: "#9A2C2C", fontWeight: "900", fontSize: 12 },
  accordionBtn: { backgroundColor: "rgba(0,0,0,0.03)", borderRadius: 12, borderWidth: 1, borderColor: "rgba(0,0,0,0.06)", paddingVertical: 10, paddingHorizontal: 12 },

  chip: { paddingVertical: 8, paddingHorizontal: 10, borderRadius: 999, marginRight: 10, marginBottom: 10, backgroundColor: "rgba(255,255,255,0.9)", borderWidth: 1, borderColor: "rgba(0,0,0,0.12)" },
  chipActive: { backgroundColor: "#0B0B0F", borderColor: "#0B0B0F" },
  chipText: { color: "#0B0B0F", fontWeight: "700", fontSize: 12 },
  chipTextActive: { color: "white", fontWeight: "800", fontSize: 12 },

  progressDayChip: { width: 68, borderRadius: 14, padding: 10, marginRight: 8, alignItems: "center", borderWidth: 1, borderColor: "rgba(0,0,0,0.08)", backgroundColor: "rgba(255,255,255,0.9)" },
  progressDayChipActive: { borderColor: "rgba(68,142,255,0.42)", backgroundColor: "rgba(68,142,255,0.08)" },
  progressDot: { width: 8, height: 8, borderRadius: 999, marginTop: 6 },
  progressDone: { backgroundColor: "#2ECC8D" },
  progressPlanned: { backgroundColor: "#448EFF" },
  progressNone: { backgroundColor: "rgba(0,0,0,0.2)" },
  statMini: { minWidth: 100, backgroundColor: "rgba(0,0,0,0.03)", borderRadius: 14, padding: 10, marginRight: 8, marginBottom: 8, borderWidth: 1, borderColor: "rgba(0,0,0,0.05)" },
  trendRow: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", height: 120, marginTop: 8 },
  trendBarWrap: { width: 28, alignItems: "center", justifyContent: "flex-end" },
  trendBar: { width: 18, borderRadius: 8, backgroundColor: "rgba(68,142,255,0.6)" },
  trendLabel: { marginTop: 6, fontSize: 11, color: "#5C5C66", fontWeight: "700" },

  planItem: { backgroundColor: "rgba(0,0,0,0.03)", borderRadius: DS.radius.input, padding: 12, borderWidth: 1, borderColor: "rgba(0,0,0,0.05)", marginBottom: 14 },
  planItemCompact: { backgroundColor: "rgba(0,0,0,0.02)", borderRadius: DS.radius.input, paddingHorizontal: 14, paddingVertical: 12, borderWidth: 1, borderColor: "rgba(0,0,0,0.05)", marginBottom: 6 },
  planItemExpanded: { backgroundColor: "rgba(0,0,0,0.04)", borderColor: "rgba(0,0,0,0.10)" },
  compactMeta: { color: "#8E8E93", fontSize: 13, fontWeight: "700" },
  planSetBlock: { backgroundColor: "rgba(0,0,0,0.02)", borderRadius: 12, padding: 10, marginTop: 8, borderWidth: 1, borderColor: "rgba(0,0,0,0.04)" },
  sectionDivider: { flexDirection: "row", alignItems: "center", marginTop: 20, marginBottom: 12, paddingHorizontal: 4 },
  sectionLine: { flex: 1, height: 1, backgroundColor: "rgba(0,0,0,0.08)" },
  sectionLabel: { paddingHorizontal: 14, fontSize: 13, fontWeight: "800", color: "#3A3A44", letterSpacing: 0.8, textTransform: "uppercase" },
  backRow: { marginBottom: 4, paddingVertical: 6 },
  backText: { fontSize: 15, fontWeight: "600", color: "#448EFF" },
  bigButton: { backgroundColor: "#0B0B0F", borderRadius: 16, paddingVertical: 16, alignItems: "center", marginTop: 12, marginBottom: 8 },
  bigButtonText: { color: "white", fontWeight: "800", fontSize: 16, letterSpacing: 0.3 },
  softButton: { backgroundColor: "rgba(0,0,0,0.06)", borderRadius: 14, paddingVertical: 13, paddingHorizontal: 20, alignItems: "center", marginTop: 10 },
  softButtonText: { color: "#3A3A44", fontWeight: "700", fontSize: 15 },
  agendaCard: { backgroundColor: DS.colors.surface, borderRadius: DS.radius.card, padding: DS.spacing.m, borderWidth: 1, borderColor: DS.colors.border, marginBottom: 12 },
  agendaDone: { opacity: 0.5 },
  agendaTitle: { fontSize: 18, fontWeight: "800", color: "#0B0B0F" },
  agendaMeta: { color: "#5C5C66", fontSize: 13, fontWeight: "600", marginTop: 4 },
  agendaStatus: { color: "#2ECC8D", fontSize: 13, fontWeight: "800", marginTop: 8 },
  inputCompact: { backgroundColor: "rgba(255,255,255,0.95)", borderWidth: 1, borderColor: "rgba(0,0,0,0.08)", paddingHorizontal: 12, paddingVertical: 11, borderRadius: 12, color: "#0B0B0F", fontSize: 16, fontWeight: "700", textAlign: "center" },
  setNumLabel: { width: 22, fontSize: 13, fontWeight: "700", color: "#8E8E93", paddingTop: 12 },
  doneBtnSmall: { backgroundColor: "#0B0B0F", borderRadius: 12, height: 42, paddingHorizontal: 14, alignItems: "center", justifyContent: "center" },
  doneBtnSmallText: { color: "white", fontWeight: "800", fontSize: 13 },
  doneSetRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 8, paddingHorizontal: 12, borderRadius: 12, backgroundColor: "rgba(46,204,141,0.08)", marginBottom: 4 },
  doneSetText: { color: "#0B0B0F", fontWeight: "700", fontSize: 14 },
  doneSetUndo: { color: "#8E8E93", fontWeight: "600", fontSize: 12 },
  suggestionText: { color: "#448EFF", fontSize: 12, fontWeight: "600", marginTop: 6, paddingLeft: 22 },
  prText: { color: "#2ECC8D", fontSize: 13, fontWeight: "800", marginTop: 6, paddingLeft: 22 },
  activeExercise: { borderColor: "#448EFF", borderWidth: 2, backgroundColor: "rgba(68,142,255,0.04)" },
  checkRow: { paddingVertical: 14, paddingHorizontal: 14, borderRadius: 12, backgroundColor: "rgba(0,0,0,0.03)", marginBottom: 4, borderWidth: 1, borderColor: "rgba(0,0,0,0.06)" },
  howtoItem: { color: "#3A3A44", fontSize: 14, fontWeight: "600", lineHeight: 22, marginBottom: 6 },
  setRow: { flexDirection: "row", marginTop: 10 },
  workoutSetRow: { flexDirection: "row", alignItems: "flex-end", marginTop: 10 },

  doneBtn: { height: 42, paddingHorizontal: 12, borderRadius: 14, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  doneBtnOn: { backgroundColor: "#0B0B0F", borderColor: "#0B0B0F" },
  doneBtnOff: { backgroundColor: "rgba(255,255,255,0.9)", borderColor: "rgba(0,0,0,0.12)" },
  doneTextOn: { color: "white", fontWeight: "900", fontSize: 12 },
  doneTextOff: { color: "#0B0B0F", fontWeight: "900", fontSize: 12 },

  /* ===== REDESIGNED TAB BAR ===== */
  tabBar: {
    position: "absolute",
    left: 20,
    right: 20,
    bottom: TAB_BOTTOM,
    flexDirection: "row",
    backgroundColor: "rgba(255,255,255,0.88)",
    borderRadius: 22,
    borderWidth: 0.5,
    borderColor: "rgba(0,0,0,0.06)",
    height: 56,
    paddingVertical: 6,
    paddingHorizontal: 4,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 6 },
    elevation: 8,
  },
  tabBtn: {
    flex: 1,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: 2,
    paddingVertical: 6,
  },
  tabBtnActive: {
    backgroundColor: "rgba(0,0,0,0.05)",
  },
  tabDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: "#0B0B0F",
    marginBottom: 4,
  },
  tabLabel: {
    color: "#8E8E93",
    fontWeight: "600",
    fontSize: 11,
    letterSpacing: 0.2,
  },
  tabLabelActive: {
    color: "#0B0B0F",
    fontWeight: "800",
    fontSize: 11,
  },

  modalRoot: { flex: 1, backgroundColor: DS.colors.bg },
  modalHeader: { paddingHorizontal: DS.spacing.l, paddingTop: DS.spacing.xs, paddingBottom: DS.spacing.s, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  modalTitle: { fontSize: 18, fontWeight: "900", color: "#0B0B0F" },

  detailSetRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 10, paddingHorizontal: 12, borderRadius: 14, borderWidth: 1, borderColor: "rgba(0,0,0,0.08)", backgroundColor: "rgba(255,255,255,0.9)", marginBottom: 10 },
  detailSetDone: { backgroundColor: "rgba(11,11,15,0.92)", borderColor: "rgba(11,11,15,0.92)" },
  detailSetText: { color: "#0B0B0F", fontWeight: "800", fontSize: 12 },
  detailSetTextDone: { color: "white", fontWeight: "900", fontSize: 12 },
  detailBadge: { color: "#5C5C66", fontSize: 12, fontWeight: "800" },
  detailBadgeDone: { color: "white", fontSize: 12, fontWeight: "900" },

  toastWrap: { position: "absolute", top: 48, left: 16, right: 16, backgroundColor: "rgba(11,11,15,0.92)", borderRadius: 14, paddingVertical: 10, paddingHorizontal: 12, zIndex: 40 },
  toastError: { backgroundColor: "rgba(120,20,20,0.92)" },
  toastSuccess: { backgroundColor: "rgba(20,90,40,0.92)" },
  toastText: { color: "white", fontWeight: "700", fontSize: 13 },

  celebrationOverlay: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(11,11,15,0.12)", zIndex: 35 },
  celebrationCard: { backgroundColor: "rgba(255,255,255,0.94)", borderRadius: 22, paddingHorizontal: 22, paddingVertical: 18, borderWidth: 1, borderColor: DS.colors.border, alignItems: "center" },
});

